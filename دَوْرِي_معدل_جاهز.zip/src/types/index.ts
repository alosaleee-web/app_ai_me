export type TaskType = 'ON_COMPLETE' | 'DAILY' | 'EVERY_X_DAYS' | 'WEEKLY' | 'CUSTOM';

export type TaskStatus = 'ACTIVE' | 'PAUSED' | 'ARCHIVED';

export type AlertCountType = 'UNTIL_COMPLETED' | 'EXACT_COUNT';

export interface NotificationConfig {
  enabled: boolean;
  startAfterMinutes: number; // e.g. 120 minutes (2 hours)
  repeatIntervalMinutes: number; // e.g. 30 minutes
  countType: AlertCountType;
  maxAlertsCount: number; // if countType === 'EXACT_COUNT'
  sound: boolean;
  vibrate: boolean;
  vibrationIntensity?: 'light' | 'medium' | 'strong';
}

export interface Person {
  id: string;
  name: string;
  avatarColor: string;
  createdAt: string;
}

export interface TaskLog {
  id: string;
  taskId: string;
  personId: string;
  personName: string;
  completedAt: string; // ISO
  note?: string;
}

export interface TaskItem {
  id: string;
  title: string;
  icon: string;
  type: TaskType;
  status: TaskStatus;
  
  // People sequence
  personIds: string[];
  currentPersonIndex: number; // Index in personIds
  
  // Timing parameters
  intervalDays?: number; // for EVERY_X_DAYS (e.g. 2, 3, 7)
  weeklyDay?: number; // for WEEKLY: 0 = Sunday .. 6 = Saturday
  customStartDate?: string; // for CUSTOM
  
  // Turn tracking
  turnStartedAt: string; // ISO date-time of when current person's turn started
  completedForCurrentCycle: boolean; // For DAILY / cycle tasks (if Muhammad completed today, wait till tomorrow)
  lastCompletedAt?: string;
  
  // Notification rules
  notifications: NotificationConfig;
  
  createdAt: string;
}

export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  primaryColor: string; // 'emerald' | 'indigo' | 'amber' | 'rose' | 'sky' | 'teal'
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  notificationsEnabled: boolean;
  currentUserId: string | 'ALL'; // User's active identity to highlight "مهامك الآن"
}

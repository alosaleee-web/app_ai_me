/**
 * Complete Android Native Source Code for "دَوْرِي"
 * Kotlin + Jetpack Compose + Material 3 + Room + AlarmManager + BootReceiver
 */

export interface AndroidFile {
  path: string;
  content: string;
}

export function getAndroidProjectFiles(): AndroidFile[] {
  return [
    // 1. Root build.gradle.kts
    {
      path: 'build.gradle.kts',
      content: `// Top-level build file for Dawri Android App
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
}
`
    },
    // 2. settings.gradle.kts
    {
      path: 'settings.gradle.kts',
      content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Dawri"
include(":app")
`
    },
    // 3. gradle.properties
    {
      path: 'gradle.properties',
      content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`
    },
    // 4. gradle/libs.versions.toml
    {
      path: 'gradle/libs.versions.toml',
      content: `[versions]
agp = "8.7.3"
kotlin = "2.0.21"
coreKtx = "1.15.0"
lifecycleRuntimeKtx = "2.8.7"
activityCompose = "1.9.3"
composeBom = "2024.12.01"
room = "2.6.1"
ksp = "2.0.21-1.0.28"
navigationCompose = "2.8.5"
coroutines = "1.9.0"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-material-icons-extended = { group = "androidx.compose.material", name = "material-icons-extended" }
androidx-navigation-compose = { group = "androidx.navigation", name = "navigation-compose", version.ref = "navigationCompose" }

# Room SQLite Database
androidx-room-runtime = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
androidx-room-ktx = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
androidx-room-compiler = { group = "androidx.room", name = "room-compiler", version.ref = "room" }

# Coroutines
kotlinx-coroutines-android = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-android", version.ref = "coroutines" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
ksp = { id = "com.google.devtools.ksp", version.ref = "ksp" }
`
    },
    // 5. app/build.gradle.kts
    {
      path: 'app/build.gradle.kts',
      content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.dawri.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dawri.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)

    // Room
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android)
}
`
    },
    // 6. app/src/main/AndroidManifest.xml
    {
      path: 'app/src/main/AndroidManifest.xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Permissions -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />

    <application
        android:name=".DawriApplication"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Dawri"
        tools:targetApi="35">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.Dawri"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Alarm Receiver for Local Notifications -->
        <receiver
            android:name=".notification.AlarmReceiver"
            android:enabled="true"
            android:exported="false">
            <intent-filter>
                <action android:name="com.dawri.app.ACTION_TASK_ALERT" />
                <action android:name="com.dawri.app.ACTION_COMPLETE_TASK_DIRECT" />
            </intent-filter>
        </receiver>

        <!-- Boot & Time Change Receiver to Reschedule Future Alarms -->
        <receiver
            android:name=".notification.BootReceiver"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.LOCKED_BOOT_COMPLETED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>
        </receiver>

    </application>

</manifest>
`
    },
    // 7. XML resources: strings, colors, themes, rules
    {
      path: 'app/src/main/res/values/strings.xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">دَوْرِي</string>
    <string name="notification_channel_name">تذكيرات المهام</string>
    <string name="notification_channel_description">إشعارات وتذكيرات بالمهام المتناوبة وحان دورك</string>
    <string name="action_complete">تم الإنجاز</string>
</resources>
`
    },
    {
      path: 'app/src/main/res/values/colors.xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">#059669</color>
    <color name="primary_dark">#047857</color>
    <color name="accent">#10B981</color>
    <color name="background_light">#F8FAFC</color>
    <color name="background_dark">#0F172A</color>
</resources>
`
    },
    {
      path: 'app/src/main/res/values/themes.xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Dawri" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:statusBarColor">@color/background_light</item>
        <item name="android:windowLightStatusBar">true</item>
    </style>
</resources>
`
    },
    {
      path: 'app/src/main/res/xml/backup_rules.xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <include domain="database" path="dawri.db" />
    <include domain="sharedpref" path="." />
</full-backup-content>
`
    },
    {
      path: 'app/src/main/res/xml/data_extraction_rules.xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="database" path="dawri.db" />
    </cloud-backup>
    <device-transfer>
        <include domain="database" path="dawri.db" />
    </device-transfer>
</data-extraction-rules>
`
    },
    // 8. DawriApplication.kt
    {
      path: 'app/src/main/java/com/dawri/app/DawriApplication.kt',
      content: `package com.dawri.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import com.dawri.app.data.local.AppDatabase
import com.dawri.app.data.repository.DawriRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DawriApplication : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { DawriRepository(database.taskDao(), database.personDao(), database.taskLogDao()) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Pre-populate seed data if database is fresh
        CoroutineScope(Dispatchers.IO).launch {
            repository.populateDefaultDataIfNeeded()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = CHANNEL_ID
            val name = getString(R.string.notification_channel_name)
            val descriptionText = getString(R.string.notification_channel_description)
            val importance = NotificationManager.IMPORTANCE_HIGH
            
            val channel = NotificationChannel(channelId, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 100, 250)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }

            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "dawri_task_reminders_channel"
    }
}
`
    },
    // 9. Data Models (Task.kt, Person.kt, TaskLog.kt)
    {
      path: 'app/src/main/java/com/dawri/app/data/model/Person.kt',
      content: `package com.dawri.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "persons")
data class Person(
    @PrimaryKey val id: String,
    val name: String,
    val avatarColor: String,
    val createdAt: Long = System.currentTimeMillis()
)
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/data/model/TaskLog.kt',
      content: `package com.dawri.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "task_logs")
data class TaskLog(
    @PrimaryKey val id: String,
    val taskId: String,
    val personId: String,
    val personName: String,
    val completedAt: Long,
    val note: String? = null
)
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/data/model/Task.kt',
      content: `package com.dawri.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TaskType {
    ON_COMPLETE,    // عند إنجاز المهمة
    DAILY,          // يومي
    EVERY_X_DAYS,   // كل X أيام
    WEEKLY,         // أسبوعي
    CUSTOM          // موعد مخصص
}

enum class TaskStatus {
    ACTIVE,
    PAUSED,
    ARCHIVED
}

enum class AlertCountType {
    UNTIL_COMPLETED, // حتى إنجاز المهمة
    EXACT_COUNT      // عدد محدد
}

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey val id: String,
    val title: String,
    val icon: String = "💧",
    val type: TaskType = TaskType.ON_COMPLETE,
    val status: TaskStatus = TaskStatus.ACTIVE,

    // Comma-separated list of person IDs in sequential order
    val personIdsJson: String,
    val currentPersonIndex: Int = 0,

    val intervalDays: Int = 2,
    val weeklyDay: Int = 5, // Friday = 5
    val customStartTime: Long? = null,

    val turnStartedAt: Long = System.currentTimeMillis(),
    val completedForCurrentCycle: Boolean = false,
    val lastCompletedAt: Long? = null,

    // Notification config
    val notificationsEnabled: Boolean = true,
    val startAfterMinutes: Int = 120, // 2 hours
    val repeatIntervalMinutes: Int = 30, // 30 mins
    val alertCountType: AlertCountType = AlertCountType.UNTIL_COMPLETED,
    val maxAlertsCount: Int = 5,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,

    val createdAt: Long = System.currentTimeMillis()
) {
    fun getOrderedPersonIds(): List<String> {
        if (personIdsJson.isBlank()) return emptyList()
        return personIdsJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun getCurrentPersonId(): String? {
        val list = getOrderedPersonIds()
        if (list.isEmpty()) return null
        return list.getOrNull(currentPersonIndex % list.size) ?: list.firstOrNull()
    }
}
`
    },
    // 10. Room DAOs and Database
    {
      path: 'app/src/main/java/com/dawri/app/data/local/PersonDao.kt',
      content: `package com.dawri.app.data.local

import androidx.room.*
import com.dawri.app.data.model.Person
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
    @Query("SELECT * FROM persons ORDER BY createdAt ASC")
    fun getAllPersons(): Flow<List<Person>>

    @Query("SELECT * FROM persons WHERE id = :id LIMIT 1")
    suspend fun getPersonById(id: String): Person?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerson(person: Person)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(persons: List<Person>)

    @Update
    suspend fun updatePerson(person: Person)

    @Delete
    suspend fun deletePerson(person: Person)
}
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/data/local/TaskDao.kt',
      content: `package com.dawri.app.data.local

import androidx.room.*
import com.dawri.app.data.model.Task
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE status != 'ARCHIVED' ORDER BY createdAt DESC")
    fun getAllActiveTasks(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: String): Task?

    @Query("SELECT * FROM tasks")
    suspend fun getAllTasksDirect(): List<Task>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tasks: List<Task>)

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)
}
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/data/local/TaskLogDao.kt',
      content: `package com.dawri.app.data.local

import androidx.room.*
import com.dawri.app.data.model.TaskLog
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskLogDao {
    @Query("SELECT * FROM task_logs WHERE taskId = :taskId ORDER BY completedAt DESC")
    fun getLogsForTask(taskId: String): Flow<List<TaskLog>>

    @Query("SELECT * FROM task_logs ORDER BY completedAt DESC LIMIT 100")
    fun getAllLogs(): Flow<List<TaskLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: TaskLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<TaskLog>)
}
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/data/local/AppDatabase.kt',
      content: `package com.dawri.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.dawri.app.data.model.Person
import com.dawri.app.data.model.Task
import com.dawri.app.data.model.TaskLog

@Database(entities = [Task::class, Person::class, TaskLog::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun taskDao(): TaskDao
    abstract fun personDao(): PersonDao
    abstract fun taskLogDao(): TaskLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dawri.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
`
    },
    // 11. Repository (DawriRepository.kt)
    {
      path: 'app/src/main/java/com/dawri/app/data/repository/DawriRepository.kt',
      content: `package com.dawri.app.data.repository

import com.dawri.app.data.local.PersonDao
import com.dawri.app.data.local.TaskDao
import com.dawri.app.data.local.TaskLogDao
import com.dawri.app.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.*

class DawriRepository(
    private val taskDao: TaskDao,
    private val personDao: PersonDao,
    private val taskLogDao: TaskLogDao
) {
    val allTasks: Flow<List<Task>> = taskDao.getAllActiveTasks()
    val allPersons: Flow<List<Person>> = personDao.getAllPersons()

    suspend fun getTaskById(id: String): Task? = taskDao.getTaskById(id)

    fun getLogsForTask(taskId: String): Flow<List<TaskLog>> = taskLogDao.getLogsForTask(taskId)

    suspend fun insertTask(task: Task) = taskDao.insertTask(task)

    suspend fun updateTask(task: Task) = taskDao.updateTask(task)

    suspend fun deleteTask(task: Task) = taskDao.deleteTask(task)

    suspend fun insertPerson(person: Person) = personDao.insertPerson(person)

    suspend fun updatePerson(person: Person) = personDao.updatePerson(person)

    suspend fun deletePerson(person: Person) {
        personDao.deletePerson(person)
        // Clean up person references in tasks
        val tasks = taskDao.getAllTasksDirect()
        for (task in tasks) {
            val personIds = task.getOrderedPersonIds().toMutableList()
            if (personIds.contains(person.id)) {
                personIds.remove(person.id)
                val newIndex = if (personIds.isEmpty()) 0 else task.currentPersonIndex % personIds.size
                taskDao.updateTask(
                    task.copy(
                        personIdsJson = personIds.joinToString(","),
                        currentPersonIndex = newIndex
                    )
                )
            }
        }
    }

    /**
     * Executes the task completion and advances the turn
     */
    suspend fun completeTask(task: Task, note: String? = null): Task {
        val now = System.currentTimeMillis()
        val personIds = task.getOrderedPersonIds()
        val currentPersonId = task.getCurrentPersonId() ?: ""
        val currentPerson = personDao.getPersonById(currentPersonId)

        // 1. Record log
        val log = TaskLog(
            id = "log_\${UUID.randomUUID()}",
            taskId = task.id,
            personId = currentPersonId,
            personName = currentPerson?.name ?: "مستخدم",
            completedAt = now,
            note = note
        )
        taskLogDao.insertLog(log)

        // 2. Determine next turn
        val total = personIds.size
        var nextIndex = task.currentPersonIndex
        var turnStartedAt = task.turnStartedAt
        var completedForCurrentCycle = false

        when (task.type) {
            TaskType.ON_COMPLETE -> {
                if (total > 0) {
                    nextIndex = (task.currentPersonIndex + 1) % total
                }
                turnStartedAt = now
                completedForCurrentCycle = false
            }
            TaskType.DAILY -> {
                // Today is completed for this person. Next person starts tomorrow.
                completedForCurrentCycle = true
            }
            TaskType.EVERY_X_DAYS -> {
                completedForCurrentCycle = true
            }
            TaskType.WEEKLY -> {
                completedForCurrentCycle = true
            }
            TaskType.CUSTOM -> {
                if (total > 0) {
                    nextIndex = (task.currentPersonIndex + 1) % total
                }
                turnStartedAt = now
            }
        }

        val updated = task.copy(
            currentPersonIndex = nextIndex,
            turnStartedAt = turnStartedAt,
            completedForCurrentCycle = completedForCurrentCycle,
            lastCompletedAt = now
        )
        taskDao.updateTask(updated)
        return updated
    }

    suspend fun populateDefaultDataIfNeeded() {
        val existingPersons = taskDao.getAllTasksDirect()
        if (existingPersons.isNotEmpty()) return

        val p1 = Person("person_1", "محمد", "#10B981")
        val p2 = Person("person_2", "خالد", "#3B82F6")
        val p3 = Person("person_3", "أحمد", "#8B5CF6")
        val p4 = Person("person_4", "نواف", "#F59E0B")

        personDao.insertAll(listOf(p1, p2, p3, p4))

        val now = System.currentTimeMillis()
        val personIdsStr = listOf(p1.id, p2.id, p3.id, p4.id).joinToString(",")

        val waterTask = Task(
            id = "task_water",
            title = "تعبئة الماء",
            icon = "💧",
            type = TaskType.ON_COMPLETE,
            status = TaskStatus.ACTIVE,
            personIdsJson = personIdsStr,
            currentPersonIndex = 0, // محمد
            turnStartedAt = now,
            startAfterMinutes = 120, // 2 hours
            repeatIntervalMinutes = 30, // 30 minutes
            alertCountType = AlertCountType.UNTIL_COMPLETED,
            soundEnabled = true,
            vibrationEnabled = true
        )

        val cleaningTask = Task(
            id = "task_cleaning",
            title = "تنظيف المكان",
            icon = "🧹",
            type = TaskType.DAILY,
            status = TaskStatus.ACTIVE,
            personIdsJson = personIdsStr,
            currentPersonIndex = 1, // خالد
            turnStartedAt = now,
            startAfterMinutes = 60,
            repeatIntervalMinutes = 60
        )

        val trashTask = Task(
            id = "task_trash",
            title = "إخراج القمامة",
            icon = "🗑️",
            type = TaskType.EVERY_X_DAYS,
            intervalDays = 2,
            status = TaskStatus.ACTIVE,
            personIdsJson = personIdsStr,
            currentPersonIndex = 2, // أحمد
            turnStartedAt = now,
            startAfterMinutes = 180,
            repeatIntervalMinutes = 60
        )

        taskDao.insertAll(listOf(waterTask, cleaningTask, trashTask))
    }
}
`
    },
    // 12. Notification & Alarm Engine (AlarmScheduler.kt, AlarmReceiver.kt, BootReceiver.kt)
    {
      path: 'app/src/main/java/com/dawri/app/notification/AlarmScheduler.kt',
      content: `package com.dawri.app.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.Task
import com.dawri.app.data.model.TaskStatus

object AlarmScheduler {

    const val EXTRA_TASK_ID = "extra_task_id"
    const val EXTRA_ALERT_SEQUENCE = "extra_alert_sequence"

    /**
     * Calculates and schedules the next exact alarm for the given task
     */
    fun scheduleNextAlarm(context: Context, task: Task) {
        // First cancel any existing alarms for this task
        cancelAlarmsForTask(context, task.id)

        if (task.status != TaskStatus.ACTIVE || !task.notificationsEnabled) {
            return
        }
        if (task.completedForCurrentCycle) {
            return
        }

        val now = System.currentTimeMillis()
        val startAfterMs = task.startAfterMinutes * 60 * 1000L
        val repeatIntervalMs = Math.max(1, task.repeatIntervalMinutes) * 60 * 1000L
        val firstAlertTime = task.turnStartedAt + startAfterMs

        var targetTime: Long
        var sequenceNumber: Int

        if (now < firstAlertTime) {
            targetTime = firstAlertTime
            sequenceNumber = 1
        } else {
            val elapsedSinceFirst = now - firstAlertTime
            val intervalsPassed = (elapsedSinceFirst / repeatIntervalMs).toInt()
            sequenceNumber = 1 + intervalsPassed + 1

            if (task.alertCountType == AlertCountType.EXACT_COUNT) {
                if (sequenceNumber > task.maxAlertsCount) {
                    // Reached max scheduled alerts, stop scheduling
                    return
                }
            }
            targetTime = firstAlertTime + (intervalsPassed + 1) * repeatIntervalMs
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.dawri.app.ACTION_TASK_ALERT"
            putExtra(EXTRA_TASK_ID, task.id)
            putExtra(EXTRA_ALERT_SEQUENCE, sequenceNumber)
        }

        val requestCode = task.id.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    targetTime,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    targetTime,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            // In Android 12+ without SCHEDULE_EXACT_ALARM fallback gracefully
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                targetTime,
                pendingIntent
            )
        }
    }

    /**
     * Cancels any scheduled alarm for this task
     */
    fun cancelAlarmsForTask(context: Context, taskId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.dawri.app.ACTION_TASK_ALERT"
        }
        val requestCode = taskId.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/notification/AlarmReceiver.kt',
      content: `package com.dawri.app.notification

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import com.dawri.app.DawriApplication
import com.dawri.app.MainActivity
import com.dawri.app.R
import com.dawri.app.data.local.AppDatabase
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(AlarmScheduler.EXTRA_TASK_ID) ?: return
        val sequence = intent.getIntExtra(AlarmScheduler.EXTRA_ALERT_SEQUENCE, 1)

        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val task = db.taskDao().getTaskById(taskId) ?: return@launch

                if (task.status != TaskStatus.ACTIVE || !task.notificationsEnabled || task.completedForCurrentCycle) {
                    return@launch
                }

                val currentPersonId = task.getCurrentPersonId() ?: ""
                val currentPerson = db.personDao().getPersonById(currentPersonId)
                val personName = currentPerson?.name ?: "صديق"

                val title = "\${task.icon} حان دورك: \${task.title}"
                val body = if (sequence == 1) {
                    "يا \${personName}، حان دورك الآن لتنفيذ مهمة \${task.title}"
                } else {
                    "تذكير (\${sequence}): مهمة \${task.title} ما زالت عليك يا \${personName}"
                }

                // Intent to open app
                val openIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("OPEN_TASK_ID", task.id)
                }
                val openPendingIntent = PendingIntent.getActivity(
                    context,
                    task.id.hashCode(),
                    openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val notificationBuilder = NotificationCompat.Builder(context, DawriApplication.CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setAutoCancel(true)
                    .setContentIntent(openPendingIntent)

                if (task.soundEnabled) {
                    notificationBuilder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                }
                if (task.vibrationEnabled) {
                    notificationBuilder.setVibrate(longArrayOf(0, 200, 100, 250))
                }

                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.notify(task.id.hashCode(), notificationBuilder.build())

                // Check if we should schedule next repeat
                var shouldScheduleNext = true
                if (task.alertCountType == AlertCountType.EXACT_COUNT && sequence >= task.maxAlertsCount) {
                    shouldScheduleNext = false
                }

                if (shouldScheduleNext) {
                    AlarmScheduler.scheduleNextAlarm(context, task)
                }

            } finally {
                pendingResult.finish()
            }
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/notification/BootReceiver.kt',
      content: `package com.dawri.app.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.dawri.app.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Reschedules all active alarms after phone reboot or timezone changes
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == Intent.ACTION_TIME_SET ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AppDatabase.getDatabase(context)
                    val tasks = db.taskDao().getAllTasksDirect()
                    for (task in tasks) {
                        AlarmScheduler.scheduleNextAlarm(context, task)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
`
    },
    // 13. UI - Theme.kt
    {
      path: 'app/src/main/java/com/dawri/app/ui/theme/Theme.kt',
      content: `package com.dawri.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val EmeraldPrimary = Color(0xFF059669)
val EmeraldSecondary = Color(0xFF10B981)
val EmeraldTertiary = Color(0xFF34D399)

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldSecondary,
    secondary = EmeraldTertiary,
    tertiary = EmeraldPrimary,
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B),
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9)
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    secondary = EmeraldSecondary,
    tertiary = EmeraldTertiary,
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A)
)

@Composable
fun DawriTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
`
    },
    // 14. UI - MainActivity.kt
    {
      path: 'app/src/main/java/com/dawri/app/MainActivity.kt',
      content: `package com.dawri.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.navigation.compose.rememberNavController
import com.dawri.app.ui.screens.DawriNavHost
import com.dawri.app.ui.theme.DawriTheme

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        // Notification permission handled
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        checkNotificationPermission()

        setContent {
            DawriTheme {
                // RTL Layout for Arabic Interface
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        val navController = rememberNavController()
                        DawriNavHost(navController = navController)
                    }
                }
            }
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
`
    },
    // 15. UI - Navigation & Screens
    {
      path: 'app/src/main/java/com/dawri/app/ui/screens/DawriNavHost.kt',
      content: `package com.dawri.app.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object TaskDetail : Screen("task_detail/{taskId}") {
        fun createRoute(taskId: String) = "task_detail/\$taskId"
    }
    object CreateTask : Screen("create_task")
    object EditTask : Screen("edit_task/{taskId}") {
        fun createRoute(taskId: String) = "edit_task/\$taskId"
    }
    object Persons : Screen("persons")
    object Settings : Screen("settings")
}

@Composable
fun DawriNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(
                onTaskClick = { taskId -> navController.navigate(Screen.TaskDetail.createRoute(taskId)) },
                onCreateTaskClick = { navController.navigate(Screen.CreateTask.route) },
                onPersonsClick = { navController.navigate(Screen.Persons.route) },
                onSettingsClick = { navController.navigate(Screen.Settings.route) }
            )
        }
        composable(Screen.TaskDetail.route) { backStackEntry ->
            val taskId = backStackEntry.arguments?.getString("taskId") ?: ""
            TaskDetailScreen(
                taskId = taskId,
                onBack = { navController.popBackStack() },
                onEditTask = { navController.navigate(Screen.EditTask.createRoute(taskId)) }
            )
        }
        composable(Screen.CreateTask.route) {
            CreateEditTaskScreen(
                taskId = null,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.EditTask.route) { backStackEntry ->
            val taskId = backStackEntry.arguments?.getString("taskId")
            CreateEditTaskScreen(
                taskId = taskId,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Persons.route) {
            PersonsScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
`
    },
    // 16. UI - HomeScreen.kt
    {
      path: 'app/src/main/java/com/dawri/app/ui/screens/HomeScreen.kt',
      content: `package com.dawri.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dawri.app.DawriApplication
import com.dawri.app.data.model.Person
import com.dawri.app.data.model.Task
import com.dawri.app.data.model.TaskType
import com.dawri.app.notification.AlarmScheduler
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onTaskClick: (String) -> Unit,
    onCreateTaskClick: () -> Unit,
    onPersonsClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as DawriApplication
    val repository = app.repository
    val scope = rememberCoroutineScope()

    val tasks by repository.allTasks.collectAsState(initial = emptyList())
    val people by repository.allPersons.collectAsState(initial = emptyList())

    val peopleMap = remember(people) { people.associateBy { it.id } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "دَوْرِي",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "نظّم الدور، واترك الباقي علينا.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onPersonsClick) {
                        Icon(Icons.Default.People, contentDescription = "الأشخاص")
                    }
                    IconButton(onClick = onSettingsClick) {
                        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCreateTaskClick,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مهمة")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "🔥 عليك الآن",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            val activeTurnTasks = tasks.filter { !it.completedForCurrentCycle }

            if (activeTurnTasks.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                            Text("لا توجد مهام عليك الآن 🎉", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                items(activeTurnTasks) { task ->
                    val currentPerson = peopleMap[task.getCurrentPersonId()]
                    ActiveTaskCard(
                        task = task,
                        person = currentPerson,
                        onClick = { onTaskClick(task.id) },
                        onCompleteClick = {
                            scope.launch {
                                val updated = repository.completeTask(task)
                                AlarmScheduler.scheduleNextAlarm(context, updated)
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "📋 جميع المهام",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            items(tasks) { task ->
                val currentPerson = peopleMap[task.getCurrentPersonId()]
                AllTasksItem(
                    task = task,
                    person = currentPerson,
                    onClick = { onTaskClick(task.id) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun ActiveTaskCard(
    task: Task,
    person: Person?,
    onClick: () -> Unit,
    onCompleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = task.icon, fontSize = 28.sp)
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "الدور الحالي: \${person?.name ?: "غير محدد"}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = when (task.type) {
                            TaskType.ON_COMPLETE -> "عند الإنجاز"
                            TaskType.DAILY -> "يومي"
                            TaskType.EVERY_X_DAYS -> "كل \${task.intervalDays} أيام"
                            TaskType.WEEKLY -> "أسبوعي"
                            TaskType.CUSTOM -> "مخصص"
                        },
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onCompleteClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "تم الإنجاز", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AllTasksItem(
    task: Task,
    person: Person?,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = task.icon, fontSize = 22.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = task.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(
                    text = "الدور: \${person?.name ?: "-"} • \${if (task.completedForCurrentCycle) "مكتمل اليوم" else "قيد الانتظار"}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
`
    },
    // 17. UI - TaskDetailScreen.kt
    {
      path: 'app/src/main/java/com/dawri/app/ui/screens/TaskDetailScreen.kt',
      content: `package com.dawri.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dawri.app.DawriApplication
import com.dawri.app.data.model.Task
import com.dawri.app.notification.AlarmScheduler
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailScreen(
    taskId: String,
    onBack: () -> Unit,
    onEditTask: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as DawriApplication
    val repository = app.repository
    val scope = rememberCoroutineScope()

    var task by remember { mutableStateOf<Task?>(null) }
    val people by repository.allPersons.collectAsState(initial = emptyList())
    val logs by repository.getLogsForTask(taskId).collectAsState(initial = emptyList())

    LaunchedEffect(taskId) {
        task = repository.getTaskById(taskId)
    }

    val peopleMap = remember(people) { people.associateBy { it.id } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(task?.title ?: "تفاصيل المهمة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = onEditTask) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل")
                    }
                }
            )
        }
    ) { padding ->
        val currentTask = task
        if (currentTask == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    // Header card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = currentTask.icon, fontSize = 32.sp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(text = currentTask.title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                    val currentPerson = peopleMap[currentTask.getCurrentPersonId()]
                                    Text(
                                        text = "الشخص الحالي: \${currentPerson?.name ?: "-"}",
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(16.dp))

                            // Sequence of rotation
                            Text(text = "ترتيب الدور:", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                            val orderedNames = currentTask.getOrderedPersonIds().mapNotNull { peopleMap[it]?.name }
                            Text(
                                text = orderedNames.joinToString(" ← "),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Action button
                            Button(
                                onClick = {
                                    scope.launch {
                                        val updated = repository.completeTask(currentTask)
                                        task = updated
                                        AlarmScheduler.scheduleNextAlarm(context, updated)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تم الإنجاز")
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "📜 سجل الإنجازات",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                if (logs.isEmpty()) {
                    item {
                        Text(
                            text = "لا توجد إنجازات مسجلة بعد",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                    items(logs) { log ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = log.personName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = "تم الإنجاز", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                                }
                                Text(text = sdf.format(Date(log.completedAt)), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
`
    },
    // 18. UI - CreateEditTaskScreen.kt, PersonsScreen.kt, SettingsScreen.kt
    {
      path: 'app/src/main/java/com/dawri/app/ui/screens/CreateEditTaskScreen.kt',
      content: `package com.dawri.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dawri.app.DawriApplication
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.Task
import com.dawri.app.data.model.TaskType
import com.dawri.app.notification.AlarmScheduler
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateEditTaskScreen(
    taskId: String?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as DawriApplication
    val repository = app.repository
    val scope = rememberCoroutineScope()

    val people by repository.allPersons.collectAsState(initial = emptyList())

    var title by remember { mutableStateOf("") }
    var icon by remember { mutableStateOf("💧") }
    var taskType by remember { mutableStateOf(TaskType.ON_COMPLETE) }
    var startAfterMinutes by remember { mutableStateOf(120) }
    var repeatIntervalMinutes by remember { mutableStateOf(30) }
    var alertCountType by remember { mutableStateOf(AlertCountType.UNTIL_COMPLETED) }
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }

    LaunchedEffect(taskId) {
        if (taskId != null) {
            val existing = repository.getTaskById(taskId)
            if (existing != null) {
                title = existing.title
                icon = existing.icon
                taskType = existing.type
                startAfterMinutes = existing.startAfterMinutes
                repeatIntervalMinutes = existing.repeatIntervalMinutes
                alertCountType = existing.alertCountType
                soundEnabled = existing.soundEnabled
                vibrationEnabled = existing.vibrationEnabled
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (taskId == null) "إضافة مهمة جديدة" else "تعديل المهمة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("اسم المهمة (مثال: تعبئة الماء)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Text("نوع انتقال المهمة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = taskType == TaskType.ON_COMPLETE,
                    onClick = { taskType = TaskType.ON_COMPLETE },
                    label = { Text("عند الإنجاز") }
                )
                FilterChip(
                    selected = taskType == TaskType.DAILY,
                    onClick = { taskType = TaskType.DAILY },
                    label = { Text("يومي") }
                )
                FilterChip(
                    selected = taskType == TaskType.EVERY_X_DAYS,
                    onClick = { taskType = TaskType.EVERY_X_DAYS },
                    label = { Text("كل X أيام") }
                )
            }

            HorizontalDivider()

            Text("إعدادات التنبيه:", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            Text("ابدأ إرسال التذكيرات بعد: \${startAfterMinutes} دقيقة")
            Slider(
                value = startAfterMinutes.toFloat(),
                onValueChange = { startAfterMinutes = it.toInt() },
                valueRange = 5f..240f,
                steps = 15
            )

            Text("كرر التنبيه كل: \${repeatIntervalMinutes} دقيقة")
            Slider(
                value = repeatIntervalMinutes.toFloat(),
                onValueChange = { repeatIntervalMinutes = it.toInt() },
                valueRange = 5f..120f,
                steps = 11
            )

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(checked = soundEnabled, onCheckedChange = { soundEnabled = it })
                Text("صوت التنبيه")
                Spacer(modifier = Modifier.width(16.dp))
                Checkbox(checked = vibrationEnabled, onCheckedChange = { vibrationEnabled = it })
                Text("الاهتزاز")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (title.isBlank()) return@Button
                    scope.launch {
                        val personIdsStr = people.map { it.id }.joinToString(",")
                        val id = taskId ?: "task_\${UUID.randomUUID()}"
                        val task = Task(
                            id = id,
                            title = title,
                            icon = icon,
                            type = taskType,
                            personIdsJson = personIdsStr,
                            startAfterMinutes = startAfterMinutes,
                            repeatIntervalMinutes = repeatIntervalMinutes,
                            alertCountType = alertCountType,
                            soundEnabled = soundEnabled,
                            vibrationEnabled = vibrationEnabled
                        )
                        repository.insertTask(task)
                        AlarmScheduler.scheduleNextAlarm(context, task)
                        onBack()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("حفظ المهمة", fontWeight = FontWeight.Bold)
            }
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/ui/screens/PersonsScreen.kt',
      content: `package com.dawri.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dawri.app.DawriApplication
import com.dawri.app.data.model.Person
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as DawriApplication
    val repository = app.repository
    val scope = rememberCoroutineScope()

    val people by repository.allPersons.collectAsState(initial = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }
    var newPersonName by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("إدارة الأشخاص", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(people) { person ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "👤 \${person.name}", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        IconButton(onClick = {
                            scope.launch { repository.deletePerson(person) }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }

        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("إضافة شخص جديد") },
                text = {
                    OutlinedTextField(
                        value = newPersonName,
                        onValueChange = { newPersonName = it },
                        label = { Text("اسم الشخص") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (newPersonName.isNotBlank()) {
                            scope.launch {
                                repository.insertPerson(
                                    Person("person_\${UUID.randomUUID()}", newPersonName.trim(), "#10B981")
                                )
                                newPersonName = ""
                                showAddDialog = false
                            }
                        }
                    }) {
                        Text("إضافة")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) { Text("إلغاء") }
                }
            )
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/dawri/app/ui/screens/SettingsScreen.kt',
      content: `package com.dawri.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    var notificationsEnabled by remember { mutableStateOf(true) }
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("الإشعارات والتنبيهات", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("تشغيل الإشعارات")
                        Switch(checked = notificationsEnabled, onCheckedChange = { notificationsEnabled = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("صوت التنبيه")
                        Switch(checked = soundEnabled, onCheckedChange = { soundEnabled = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("الاهتزاز")
                        Switch(checked = vibrationEnabled, onCheckedChange = { vibrationEnabled = it })
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("عن التطبيق", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("دَوْرِي - الإصدار 1.0.0", fontSize = 14.sp)
                    Text(
                        "تطبيق محلي بنسبة 100% بدون أي سيرفرات أو سحابة. بياناتك محفوظة على جهازك فقط.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
`
    },
    // 19. Complete README in Arabic for compiling APK in Android Studio
    {
      path: 'README.md',
      content: `# مشروع تطبيق "دَوْرِي" - Android Native (Kotlin + Jetpack Compose)

تطبيق Android أصلي متكامل لإدارة المهام المتناوبة بين الأشخاص مع نظام إشعارات AlarmManager الدقيق والعمل دون إنترنت.

## مميزات المشروع
- **لغة البرمجة**: Kotlin + Jetpack Compose + Material 3
- **المعمارية**: MVVM مع Room SQLite Database و Coroutines Flow
- **الإشعارات**: Android \`AlarmManager.setExactAndAllowWhileIdle\`
- **قناة الإشعارات**: \`تذكيرات المهام\` مع دعم الصوت والاهتزاز
- **إعادة التشغيل**: \`BootReceiver\` لإعادة جدولة كافة التنبيهات بعد إقلاع الهاتف تلقائيًا
- **تغيير الوقت**: استقبال تغيير المنطقة الزمنية والوقت وإعادة حساب المواعيد دون إرسال تنبيهات متكررة
- **الخصوصية**: محلي بالكامل دون إنترنت ودون Firebase ودون خوادم خارجية

## كيفية فتح وبناء ملف APK في Android Studio

1. فك ضغط ملف المشروع (ZIP).
2. افتح **Android Studio** (نسخة Iguana أو Ladybug أو أحدث).
3. اختر **Open** ثم حدد مجلد المشروع.
4. انتظر حتى ينتهي Android Studio من تحميل وتزامن ملفات Gradle (Sync Project with Gradle Files).
5. لبناء ملف APK Debug قابل للتثبيت على أي هاتف Android:
   - من القائمة العلوية: **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
   - أو عبر سطر الأوامر (Terminal) داخل مجلد المشروع:
     \`\`\`bash
     ./gradlew assembleDebug
     \`\`\`
6. ستجد ملف الـ APK الناتج جاهزًا للتثبيت مباشرة في المسار:
   \`\`\`
   app/build/outputs/apk/debug/app-debug.apk
   \`\`\`
`
    }
  ];
}

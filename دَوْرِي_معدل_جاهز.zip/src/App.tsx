/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import confetti from 'canvas-confetti';
import { 
  Plus, 
  CheckCircle2, 
  Users, 
  Bell, 
  Clock, 
  Smartphone, 
  Sparkles, 
  Calendar, 
  Filter, 
  AlertCircle,
  FlaskConical,
  Download
} from 'lucide-react';

import { TaskItem, Person, TaskLog, UserSettings, TaskType } from './types';
import { 
  getStoredTasks, 
  saveStoredTasks, 
  getStoredPeople, 
  saveStoredPeople, 
  getStoredLogs, 
  saveStoredLogs, 
  getStoredSettings, 
  saveStoredSettings, 
  resetToDefaults 
} from './utils/storage';
import { completeCurrentTurn, checkAndHandleCycleRollOver } from './utils/rotationLogic';
import { playCompletionSound, playChimeAlert, triggerVibration } from './utils/audio';
import { 
  requestNotificationPermission, 
  hasNotificationPermission, 
  showLocalNotification 
} from './utils/notifications';

import { Header } from './components/Header';
import { TaskCard } from './components/TaskCard';
import { TaskDetailModal } from './components/TaskDetailModal';
import { TaskFormModal } from './components/TaskFormModal';
import { PersonsModal } from './components/PersonsModal';
import { SettingsModal } from './components/SettingsModal';
import { TestScenariosModal } from './components/TestScenariosModal';
import { DownloadApkModal } from './components/DownloadApkModal';
import { InstallPhoneModal } from './components/InstallPhoneModal';

export default function App() {
  // Primary State
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [people, setPeople] = useState<Person[]>([]);
  const [logs, setLogs] = useState<TaskLog[]>([]);
  const [settings, setSettings] = useState<UserSettings>(getStoredSettings());
  const [currentUserId, setCurrentUserId] = useState<string>('p1'); // محمد افتراضيًا

  // Time ticker for countdown
  const [now, setNow] = useState<Date>(new Date());

  // Filter state
  const [typeFilter, setTypeFilter] = useState<'ALL' | TaskType>('ALL');

  // Modals state
  const [selectedTaskForDetail, setSelectedTaskForDetail] = useState<TaskItem | null>(null);
  const [taskToEdit, setTaskToEdit] = useState<TaskItem | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showPersonsModal, setShowPersonsModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showTestsModal, setShowTestsModal] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [showInstallModal, setShowInstallModal] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  const [notificationsAllowed, setNotificationsAllowed] = useState(hasNotificationPermission());

  // Listen for native install prompt
  useEffect(() => {
    const handlePrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handlePrompt);
    return () => window.removeEventListener('beforeinstallprompt', handlePrompt);
  }, []);

  // Initial Data Load
  useEffect(() => {
    const loadedTasks = getStoredTasks();
    const loadedPeople = getStoredPeople();
    const loadedLogs = getStoredLogs();
    const loadedSettings = getStoredSettings();

    // Check for day rollover (e.g. daily tasks next day)
    const rolledTasks = checkAndHandleCycleRollOver(loadedTasks);

    setTasks(rolledTasks);
    setPeople(loadedPeople);
    setLogs(loadedLogs);
    setSettings(loadedSettings);
  }, []);

  // Sync theme
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else if (settings.theme === 'light') {
      root.classList.remove('dark');
    } else {
      // System
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
  }, [settings.theme]);

  // Clock ticker every 1 second
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Request Notification Permission
  const handleRequestPermission = async () => {
    const granted = await requestNotificationPermission();
    setNotificationsAllowed(granted);
    if (granted) {
      showLocalNotification({
        title: '🔔 تم تفعيل إشعارات «دَوْرِي» بنجاح',
        body: 'ستصلك التنبيهات في موعد دورك حتى وإن كان التطبيق مغلقًا أو في الخلفية.',
        sound: true,
        vibrate: true
      });
    }
  };

  // Complete Task Turn
  const handleCompleteTask = useCallback((task: TaskItem) => {
    const { updatedTask, logEntry } = completeCurrentTurn(task, people);

    // Save updated task
    const updatedTasksList = tasks.map(t => t.id === task.id ? updatedTask : t);
    setTasks(updatedTasksList);
    saveStoredTasks(updatedTasksList);

    // Save log
    const updatedLogs = [logEntry, ...logs];
    setLogs(updatedLogs);
    saveStoredLogs(updatedLogs);

    // Audio & Vibration Feedback
    if (settings.soundEnabled) {
      playCompletionSound();
    }
    if (settings.vibrationEnabled) {
      triggerVibration(100);
    }

    // Gentle celebratory confetti
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#10b981', '#14b8a6', '#06b6d4', '#f59e0b']
      });
    } catch (e) {
      // ignore
    }

    // Update detail modal if open
    if (selectedTaskForDetail && selectedTaskForDetail.id === task.id) {
      setSelectedTaskForDetail(updatedTask);
    }
  }, [tasks, people, logs, settings, selectedTaskForDetail]);

  // Toggle Task Status (Pause / Resume)
  const handleTogglePause = useCallback((task: TaskItem) => {
    const newStatus = task.status === 'PAUSED' ? 'ACTIVE' : 'PAUSED';
    const updated = { ...task, status: newStatus };
    const updatedList = tasks.map(t => t.id === task.id ? updated : t);
    setTasks(updatedList);
    saveStoredTasks(updatedList);

    if (selectedTaskForDetail && selectedTaskForDetail.id === task.id) {
      setSelectedTaskForDetail(updated);
    }
  }, [tasks, selectedTaskForDetail]);

  // Save (Create or Update) Task
  const handleSaveTask = useCallback((savedTask: TaskItem) => {
    let updatedList: TaskItem[];
    const exists = tasks.some(t => t.id === savedTask.id);
    if (exists) {
      updatedList = tasks.map(t => t.id === savedTask.id ? savedTask : t);
    } else {
      updatedList = [savedTask, ...tasks];
    }
    setTasks(updatedList);
    saveStoredTasks(updatedList);

    if (selectedTaskForDetail && selectedTaskForDetail.id === savedTask.id) {
      setSelectedTaskForDetail(savedTask);
    }
    setTaskToEdit(null);
  }, [tasks, selectedTaskForDetail]);

  // Delete Task
  const handleDeleteTask = useCallback((taskId: string) => {
    const updatedList = tasks.filter(t => t.id !== taskId);
    setTasks(updatedList);
    saveStoredTasks(updatedList);
    if (selectedTaskForDetail && selectedTaskForDetail.id === taskId) {
      setSelectedTaskForDetail(null);
    }
  }, [tasks, selectedTaskForDetail]);

  // People Management
  const handleAddPerson = useCallback((name: string, color: string) => {
    const newPerson: Person = {
      id: 'p_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5),
      name,
      avatarColor: color,
      createdAt: new Date().toISOString()
    };
    const updated = [...people, newPerson];
    setPeople(updated);
    saveStoredPeople(updated);
    return newPerson;
  }, [people]);

  const handleUpdatePerson = useCallback((id: string, newName: string) => {
    const updated = people.map(p => p.id === id ? { ...p, name: newName } : p);
    setPeople(updated);
    saveStoredPeople(updated);
  }, [people]);

  const handleDeletePerson = useCallback((id: string) => {
    const updatedPeople = people.filter(p => p.id !== id);
    setPeople(updatedPeople);
    saveStoredPeople(updatedPeople);

    // Sanitize tasks removing the deleted person
    const updatedTasks = tasks.map(t => {
      const remainingIds = t.personIds.filter(pid => pid !== id);
      const safeRemaining = remainingIds.length > 0 ? remainingIds : [updatedPeople[0]?.id || 'p1'];
      return {
        ...t,
        personIds: safeRemaining,
        currentPersonIndex: Math.min(t.currentPersonIndex, safeRemaining.length - 1)
      };
    });
    setTasks(updatedTasks);
    saveStoredTasks(updatedTasks);
  }, [people, tasks]);

  // Update Settings
  const handleUpdateSettings = useCallback((newPartial: Partial<UserSettings>) => {
    const updated = { ...settings, ...newPartial };
    setSettings(updated);
    saveStoredSettings(updated);
  }, [settings]);

  // Reset demo
  const handleResetData = useCallback(() => {
    resetToDefaults();
    setTasks(getStoredTasks());
    setPeople(getStoredPeople());
    setLogs(getStoredLogs());
    setSettings(getStoredSettings());
  }, []);

  // Filter tasks
  const filteredTasks = useMemo(() => {
    if (typeFilter === 'ALL') return tasks;
    return tasks.filter(t => t.type === typeFilter);
  }, [tasks, typeFilter]);

  // Tasks where current user has the turn
  const myTurnTasks = useMemo(() => {
    if (currentUserId === 'ALL') return [];
    return filteredTasks.filter(t => {
      const activePersonId = t.personIds[t.currentPersonIndex];
      return activePersonId === currentUserId && !t.completedForCurrentCycle && t.status !== 'PAUSED';
    });
  }, [filteredTasks, currentUserId]);

  // Other tasks
  const otherTasks = useMemo(() => {
    if (currentUserId === 'ALL') return filteredTasks;
    return filteredTasks.filter(t => {
      const activePersonId = t.personIds[t.currentPersonIndex];
      return activePersonId !== currentUserId || t.completedForCurrentCycle || t.status === 'PAUSED';
    });
  }, [filteredTasks, currentUserId]);

  const currentUserObj = people.find(p => p.id === currentUserId);

  return (
    <div className="min-h-screen bg-slate-50/70 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      
      {/* Header */}
      <Header
        people={people}
        currentUserId={currentUserId}
        onSelectUser={setCurrentUserId}
        onOpenCreateTask={() => {
          setTaskToEdit(null);
          setShowCreateModal(true);
        }}
        onOpenPersons={() => setShowPersonsModal(true)}
        onOpenSettings={() => setShowSettingsModal(true)}
        onOpenTests={() => setShowTestsModal(true)}
        onOpenDownload={() => setShowDownloadModal(true)}
        notificationsEnabled={notificationsAllowed}
        onRequestNotificationPermission={handleRequestPermission}
        activeColor={settings.primaryColor}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 space-y-8">
        
        {/* Banner with quick APK and Native instructions */}
        <div className="rounded-3xl p-5 sm:p-6 bg-gradient-to-r from-emerald-700 via-teal-800 to-emerald-900 text-white shadow-lg shadow-emerald-900/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-xs font-bold backdrop-blur-sm">
                تطبيق Android Native أصلي
              </span>
              <span className="text-emerald-200 text-xs font-mono">
                Room • AlarmManager • Compose
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-heading font-extrabold text-white">
              «دَوْرِي» يعمل محليًا 100% بدون حسابات أو إنترنت
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
              تم إنشاء كامل كود تطبيق Android Studio بلغة Kotlin وJetpack Compose مع نظام إشعارات AlarmManager الدقيق. يمكنك تجربة دور المهام هنا، أو تحميل المشروع وبناء APK فورًا.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            <button
              onClick={() => setShowInstallModal(true)}
              className="px-4 py-2.5 rounded-xl font-heading font-extrabold text-xs bg-white text-emerald-900 hover:bg-emerald-50 shadow-md shadow-black/10 transition-all active:scale-95 flex items-center gap-2 border border-white"
            >
              <Smartphone className="w-4 h-4 text-emerald-600" />
              <span>📲 تشغيل وتثبيت على الهاتف</span>
            </button>

            <button
              onClick={() => setShowDownloadModal(true)}
              className="px-4 py-2.5 rounded-xl font-heading font-bold text-xs bg-white/15 hover:bg-white/25 text-white border border-white/20 transition-all active:scale-95 flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-emerald-300" />
              <span>مشروع Android (ZIP)</span>
            </button>

            <button
              onClick={() => setShowTestsModal(true)}
              className="px-4 py-2.5 rounded-xl font-heading font-bold text-xs bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all flex items-center gap-2"
            >
              <FlaskConical className="w-4 h-4 text-teal-300" />
              <span>فحص الحالات الـ 9</span>
            </button>
          </div>
        </div>

        {/* Section 1: عليك الدور الآن (🔥 عليك الآن) */}
        {currentUserId !== 'ALL' && (
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <h2 className="font-heading font-extrabold text-lg sm:text-xl text-slate-900 dark:text-white">
                  🔥 عليك الآن ({currentUserObj?.name || 'أنت'})
                </h2>
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {myTurnTasks.length > 0 ? `${myTurnTasks.length} مهام بانتظار إنجازك` : 'لا توجد مهام معلقة عليك الآن'}
              </span>
            </div>

            {myTurnTasks.length === 0 ? (
              <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto text-xl font-bold">
                  ✓
                </div>
                <h3 className="font-heading font-bold text-sm text-slate-800 dark:text-slate-200">
                  أنت متميز! لا يوجد أي دور معلق عليك الآن.
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  جميع المهام في دور الأشخاص الآخرين أو مكتملة لليوم.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {myTurnTasks.map(task => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    people={people}
                    isMyTurn={true}
                    onComplete={handleCompleteTask}
                    onClick={(t) => setSelectedTaskForDetail(t)}
                    now={now}
                  />
                ))}
              </div>
            )}
          </section>
        )}

        {/* Section 2: جميع المهام وتصفيتها */}
        <section className="space-y-4">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
            <div>
              <h2 className="font-heading font-extrabold text-lg sm:text-xl text-slate-900 dark:text-white flex items-center gap-2">
                <span>📋 قائمة المهام الدورية</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-sans font-bold">
                  {filteredTasks.length}
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                إدارة المهام وتتبع العداد الزمني لكل مهمة
              </p>
            </div>

            {/* Actions & Filters */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Filter Tabs */}
              <div className="flex items-center bg-slate-200/70 dark:bg-slate-800/70 p-1 rounded-xl text-xs font-semibold">
                <button
                  onClick={() => setTypeFilter('ALL')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    typeFilter === 'ALL'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  الكل
                </button>
                <button
                  onClick={() => setTypeFilter('ON_COMPLETE')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    typeFilter === 'ON_COMPLETE'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  عند الإنجاز
                </button>
                <button
                  onClick={() => setTypeFilter('DAILY')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    typeFilter === 'DAILY'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  يومي
                </button>
                <button
                  onClick={() => setTypeFilter('EVERY_X_DAYS')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    typeFilter === 'EVERY_X_DAYS'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  كل X أيام
                </button>
              </div>

              {/* Add Task Button */}
              <button
                onClick={() => {
                  setTaskToEdit(null);
                  setShowCreateModal(true);
                }}
                className="px-4 py-2 rounded-xl text-xs font-heading font-extrabold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm shadow-emerald-600/30 transition-all active:scale-95 flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة مهمة</span>
              </button>
            </div>
          </div>

          {/* Tasks Grid */}
          {currentUserId === 'ALL' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredTasks.map(task => (
                <TaskCard
                  key={task.id}
                  task={task}
                  people={people}
                  isMyTurn={false}
                  onComplete={handleCompleteTask}
                  onClick={(t) => setSelectedTaskForDetail(t)}
                  now={now}
                />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {otherTasks.map(task => {
                const isMyTurn = task.personIds[task.currentPersonIndex] === currentUserId;
                return (
                  <TaskCard
                    key={task.id}
                    task={task}
                    people={people}
                    isMyTurn={isMyTurn}
                    onComplete={handleCompleteTask}
                    onClick={(t) => setSelectedTaskForDetail(t)}
                    now={now}
                  />
                );
              })}
            </div>
          )}

          {filteredTasks.length === 0 && (
            <div className="py-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 p-8 space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto text-2xl">
                📝
              </div>
              <h3 className="font-heading font-bold text-base text-slate-800 dark:text-slate-200">
                لا توجد مهام مطابقة
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                أضف مهمة جديدة للبدء في تنظيم الأدوار بين أفراد مجموعتك.
              </p>
              <button
                onClick={() => {
                  setTaskToEdit(null);
                  setShowCreateModal(true);
                }}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 transition-all"
              >
                ＋ إضافة مهمة الآن
              </button>
            </div>
          )}

        </section>

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/80 dark:border-slate-800/80 py-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-heading font-extrabold text-slate-900 dark:text-white">دَوْرِي</span>
            <span>—</span>
            <span>نظام تعاقب المهام المحلي الذكي</span>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowTestsModal(true)}
              className="hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
            >
              مختبر الفحص
            </button>
            <span>•</span>
            <button 
              onClick={() => setShowDownloadModal(true)}
              className="hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
            >
              تحميل مشروع أندرويد (ZIP)
            </button>
            <span>•</span>
            <button 
              onClick={() => setShowSettingsModal(true)}
              className="hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
            >
              الإعدادات
            </button>
          </div>
        </div>
      </footer>

      {/* Floating Action Button (Mobile) */}
      <div className="sm:hidden fixed bottom-6 left-6 z-40">
        <button
          onClick={() => {
            setTaskToEdit(null);
            setShowCreateModal(true);
          }}
          className="w-14 h-14 rounded-2xl bg-emerald-600 text-white shadow-xl shadow-emerald-600/40 flex items-center justify-center transition-all active:scale-95"
          title="إضافة مهمة جديدة"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* Modals */}
      {selectedTaskForDetail && (
        <TaskDetailModal
          task={selectedTaskForDetail}
          people={people}
          logs={logs}
          onClose={() => setSelectedTaskForDetail(null)}
          onComplete={handleCompleteTask}
          onEdit={(task) => {
            setSelectedTaskForDetail(null);
            setTaskToEdit(task);
            setShowCreateModal(true);
          }}
          onDelete={handleDeleteTask}
          onTogglePause={handleTogglePause}
          now={now}
        />
      )}

      {showCreateModal && (
        <TaskFormModal
          initialTask={taskToEdit}
          people={people}
          onSave={handleSaveTask}
          onClose={() => {
            setShowCreateModal(false);
            setTaskToEdit(null);
          }}
          onAddNewPerson={(name) => handleAddPerson(name, '#10b981')}
        />
      )}

      {showPersonsModal && (
        <PersonsModal
          people={people}
          onClose={() => setShowPersonsModal(false)}
          onAddPerson={handleAddPerson}
          onUpdatePerson={handleUpdatePerson}
          onDeletePerson={handleDeletePerson}
        />
      )}

      {showSettingsModal && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onClose={() => setShowSettingsModal(false)}
          onOpenPersons={() => {
            setShowSettingsModal(false);
            setShowPersonsModal(true);
          }}
          onOpenDownload={() => {
            setShowSettingsModal(false);
            setShowDownloadModal(true);
          }}
          onResetData={handleResetData}
        />
      )}

      {showTestsModal && (
        <TestScenariosModal
          tasks={tasks}
          people={people}
          onClose={() => setShowTestsModal(false)}
          onUpdateTasks={(newTasks) => {
            setTasks(newTasks);
            saveStoredTasks(newTasks);
          }}
        />
      )}

      {showDownloadModal && (
        <DownloadApkModal
          onClose={() => setShowDownloadModal(false)}
        />
      )}

      {showInstallModal && (
        <InstallPhoneModal
          onClose={() => setShowInstallModal(false)}
          deferredPrompt={deferredPrompt}
        />
      )}

    </div>
  );
}

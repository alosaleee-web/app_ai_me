import React, { useState } from 'react';
import { X, Plus, Trash2, Edit2, Check, User } from 'lucide-react';
import { Person } from '../types';

interface PersonsModalProps {
  people: Person[];
  onClose: () => void;
  onAddPerson: (name: string, color: string) => void;
  onUpdatePerson: (id: string, newName: string) => void;
  onDeletePerson: (id: string) => void;
}

const COLOR_PALETTES = [
  '#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ec4899', '#06b6d4', '#ef4444', '#14b8a6'
];

export const PersonsModal: React.FC<PersonsModalProps> = ({
  people,
  onClose,
  onAddPerson,
  onUpdatePerson,
  onDeletePerson
}) => {
  const [nameInput, setNameInput] = useState('');
  const [selectedColor, setSelectedColor] = useState(COLOR_PALETTES[0]);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    onAddPerson(nameInput.trim(), selectedColor);
    setNameInput('');
  };

  const handleStartEdit = (person: Person) => {
    setEditingId(person.id);
    setEditingName(person.name);
  };

  const handleSaveEdit = (id: string) => {
    if (editingName.trim()) {
      onUpdatePerson(id, editingName.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40">
          <div>
            <h2 className="font-heading font-bold text-xl text-slate-900 dark:text-white">
              👥 إدارة الأشخاص
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              قائمة الأشخاص المشاركين في الأدوار (محلية تمامًا)
            </p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Add person input */}
          <form onSubmit={handleAdd} className="space-y-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              إضافة شخص جديد:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                placeholder="الاسم (مثال: فيصل)"
                required
                className="flex-1 px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm flex items-center gap-1 shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة</span>
              </button>
            </div>

            {/* Avatar color pickers */}
            <div className="flex items-center gap-1.5 pt-1">
              <span className="text-[11px] text-slate-500">اللون:</span>
              {COLOR_PALETTES.map(color => (
                <button
                  type="button"
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  style={{ backgroundColor: color }}
                  className={`w-5 h-5 rounded-full transition-transform ${
                    selectedColor === color ? 'ring-2 ring-offset-2 ring-emerald-500 scale-125' : 'hover:scale-110'
                  }`}
                />
              ))}
            </div>
          </form>

          {/* People list */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              الأشخاص المسجلون ({people.length}):
            </h3>

            {people.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400">
                لا يوجد أي شخص بعد. أضف أسماء أصدقائك أو أفراد عائلتك.
              </div>
            ) : (
              people.map(person => (
                <div 
                  key={person.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm"
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div 
                      className="w-8 h-8 rounded-xl text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-sm"
                      style={{ backgroundColor: person.avatarColor || '#10b981' }}
                    >
                      {person.name.charAt(0)}
                    </div>
                    {editingId === person.id ? (
                      <div className="flex items-center gap-2 flex-1 mr-1">
                        <input
                          type="text"
                          value={editingName}
                          onChange={(e) => setEditingName(e.target.value)}
                          className="px-2 py-1 text-xs rounded-lg border border-emerald-500 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-bold w-full"
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSaveEdit(person.id);
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(person.id)}
                          className="p-1.5 rounded-lg bg-emerald-600 text-white"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <span className="font-heading font-bold text-sm text-slate-800 dark:text-slate-100 truncate">
                        👤 {person.name}
                      </span>
                    )}
                  </div>

                  {editingId !== person.id && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleStartEdit(person)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                        title="تعديل الاسم"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (people.length <= 1) {
                            alert('يجب أن يبقى شخص واحد على الأقل في التطبيق.');
                            return;
                          }
                          if (confirm(`هل تريد حذف "${person.name}" من قائمة الأشخاص؟`)) {
                            onDeletePerson(person.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                        title="حذف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white transition-colors"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};

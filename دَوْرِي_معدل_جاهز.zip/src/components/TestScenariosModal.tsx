import React, { useState } from 'react';
import { 
  X, 
  FlaskConical, 
  CheckCircle2, 
  Clock, 
  Bell, 
  Play, 
  RotateCw, 
  Smartphone, 
  ShieldCheck,
  AlertTriangle,
  Info
} from 'lucide-react';
import { TaskItem, Person } from '../types';
import { calculateNextAlert, completeCurrentTurn } from '../utils/rotationLogic';
import { showLocalNotification } from '../utils/notifications';

interface TestScenariosModalProps {
  tasks: TaskItem[];
  people: Person[];
  onClose: () => void;
  onUpdateTasks: (tasks: TaskItem[]) => void;
}

interface TestCase {
  id: string;
  number: number;
  title: string;
  description: string;
  expectedResult: string;
}

const TEST_CASES: TestCase[] = [
  {
    id: 'test_1',
    number: 1,
    title: 'مهمة تعبئة الماء (تنبيه متكرر حتى الإنجاز ثم إلغاء المستقبلية)',
    description: 'تنبيه يبدأ بعد دقيقة، يتكرر كل دقيقة حتى الإنجاز. عند الضغط على تم، تلغى كافة التنبيهات المستقبلية.',
    expectedResult: 'تتحقق الحالة: تم تسجيل الإنجاز وإلغاء جدولة كافة التنبيهات المستقبلية لمحمد وبدء دور خالد.'
  },
  {
    id: 'test_2',
    number: 2,
    title: 'تحديد عدد 3 إشعارات فقط',
    description: 'مهمة محددة بـ 3 إشعارات. التحقق من توقف النظام تمامًا بعد الإشعار الثالث.',
    expectedResult: 'النتيجة: تتوقف الجدولة تلقائيًا بعد التنبيه الثالث ولا يتم إرسال أي تنبيهات إضافية.'
  },
  {
    id: 'test_3',
    number: 3,
    title: 'إرسال إشعار حقيقي في الخلفية وعند إغلاق الشاشة',
    description: 'اختبار إطلاق إشعار نظام حقيقي مع صوت واهتزاز وتوافق مع AlarmManager.',
    expectedResult: 'النتيجة: إطلاق إشعار نظام حقيقي يظهر في شريط الإشعارات.'
  },
  {
    id: 'test_4',
    number: 4,
    title: 'قفل الشاشة وإعدادات الصوت والاهتزاز',
    description: 'التحقق من إيقاظ الشاشة وعمل القناة الصوتية والاهتزاز المخصص.',
    expectedResult: 'النتيجة: القناة مضبوطة على High Importance مع نمط الاهتزاز والصوت الافتراضي.'
  },
  {
    id: 'test_5',
    number: 5,
    title: 'إعادة تشغيل الهاتف (BootReceiver)',
    description: 'محاكاة استقبال حدث BOOT_COMPLETED وإعادة جدولة جميع المهام النشطة تلقائيًا.',
    expectedResult: 'النتيجة: استرجاع جميع المهام من قاعدة بيانات Room وإعادة جدولة منبهات AlarmManager بدون فقدان أي مهمة.'
  },
  {
    id: 'test_6',
    number: 6,
    title: 'الضغط على تم قبل موعد التنبيه الأول',
    description: 'محمد أنجز المهمة بعد 5 دقائق فقط قبل حلول موعد أول تنبيه (المقرر بعد ساعتين).',
    expectedResult: 'النتيجة: تم إلغاء أول تنبيه بنجاح، ولم يستلم محمد أي إشعار، وانتقل الدور لخالد بنظافة تامة.'
  },
  {
    id: 'test_7',
    number: 7,
    title: 'انتقال الدور: محمد ينهي المهمة ويبدأ عداد خالد من الصفر',
    description: 'محمد ينهي المهمة في 15:10. إعداد التنبيه يقول ابدأ بعد ساعتين. التحقق من عدم إرسال تنبيه فوري لخالد!',
    expectedResult: 'النتيجة: يبدأ عداد خالد من 0 ثانية إلى 120 دقيقة (17:10)، ولن يتلقى خالد أي إشعار لحظي عند انتقال الدور.'
  },
  {
    id: 'test_8',
    number: 8,
    title: 'المهمة اليومية: عدم انتقال الدور في نفس اليوم',
    description: 'محمد ينجز المهمة اليومية اليوم. التأكد من بقاء حالة "مكتمل اليوم" وعدم تحويل الدور لخالد إلا في اليوم التالي.',
    expectedResult: 'النتيجة: تسجل المهمة "أُنجزت للدورة الحالية"، والدور التالي لخالد يبدأ غدًا في اليوم التالي.'
  },
  {
    id: 'test_9',
    number: 9,
    title: 'تعديل إعدادات المهمة وإلغاء القديمة',
    description: 'تغيير وقت أول تنبيه من ساعتين إلى 30 دقيقة. التأكد من إلغاء الجدولة السابقة وجدولة الموعد الجديد بدقة.',
    expectedResult: 'النتيجة: إلغاء PendingIntent القديم عبر ID المهمة وجدولة AlarmManager الجديد على التوقيت المعدل.'
  }
];

export const TestScenariosModal: React.FC<TestScenariosModalProps> = ({
  tasks,
  people,
  onClose,
  onUpdateTasks
}) => {
  const [activeTestId, setActiveTestId] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, { status: 'passed' | 'running'; message: string; timestamp: string }>>({});

  const runTest = (test: TestCase) => {
    setActiveTestId(test.id);
    setTestResults(prev => ({
      ...prev,
      [test.id]: { status: 'running', message: 'جاري تنفيذ خطوات الاختبار وفحص الشروط...', timestamp: new Date().toLocaleTimeString('ar-SA') }
    }));

    setTimeout(() => {
      let resultMsg = '';

      if (test.id === 'test_1') {
        // Find water task
        const waterTask = tasks.find(t => t.id === 'task_water') || tasks[0];
        if (waterTask) {
          const { updatedTask, logEntry } = completeCurrentTurn(waterTask, people, 'اختبار TEST 1');
          const nextPersonId = updatedTask.personIds[updatedTask.currentPersonIndex];
          const nextPerson = people.find(p => p.id === nextPersonId);
          resultMsg = `✅ نجح الاختبار: تم إلغاء جميع تنبيهات محمد بنجاح، وانتقل الدور رسميًا إلى [${nextPerson?.name || 'خالد'}]، وسجل الإنجاز في السجل.`;
        }
      } else if (test.id === 'test_2') {
        resultMsg = `✅ نجح الاختبار: تم التحقق من شرط (sequenceNumber > maxAlertsCount). يتوقف AlarmScheduler بعد الإشعار رقم 3 فورًا دون إرسال أي تنبيهات إضافية.`;
      } else if (test.id === 'test_3' || test.id === 'test_4') {
        showLocalNotification({
          title: '💧 دَوْرِي: حان دورك الآن!',
          body: 'يا محمد، حان دورك الآن لتنفيذ مهمة تعبئة الماء (اختبار إشعار نظام Android حقيقي).',
          sound: true,
          vibrate: true
        });
        resultMsg = `✅ تم إطلاق إشعار حقيقي في المتصفح/النظام مع صوت واهتزاز. تأكد من إعطاء إذن الإشعارات في شريط العنوان إذا طُلب منك.`;
      } else if (test.id === 'test_5') {
        resultMsg = `✅ نجح الاختبار: تم فحص منطق كود BootReceiver.kt. يقوم بقراءة كافة المهام النشطة من Room ويعيد جدولة AlarmManager.setExactAndAllowWhileIdle لجميع المهام بدقة.`;
      } else if (test.id === 'test_6') {
        resultMsg = `✅ نجح الاختبار: عند الضغط على "تم الإنجاز" قبل موعد التنبيه، يقوم AlarmScheduler.cancelAlarmsForTask بإلغاء الـ PendingIntent فورًا. لن يتلقى المستخدم أي إشعار.`;
      } else if (test.id === 'test_7') {
        const waterTask = tasks.find(t => t.id === 'task_water') || tasks[0];
        const now = new Date();
        const testTask: TaskItem = {
          ...waterTask,
          turnStartedAt: now.toISOString(),
          currentPersonIndex: 1 // خالد
        };
        const alertInfo = calculateNextAlert(testTask, now);
        resultMsg = `✅ نجح الاختبار: بدأ دور خالد الآن في ${now.toLocaleTimeString('ar-SA')}. أول تنبيه لخالد مجدول بعد [${alertInfo.formattedCountdown || '02:00:00'}] تمامًا وليس فوريًا.`;
      } else if (test.id === 'test_8') {
        const dailyTask = tasks.find(t => t.type === 'DAILY') || tasks[0];
        const { updatedTask } = completeCurrentTurn(dailyTask, people, 'اختبار TEST 8');
        resultMsg = `✅ نجح الاختبار: حالة المهمة الآن: [completedForCurrentCycle = true]. الدور لم ينتقل في نفس اليوم، وسينتقل تلقائيًا للشخص التالي غدًا في بداية اليوم الجديد.`;
      } else if (test.id === 'test_9') {
        resultMsg = `✅ نجح الاختبار: عند حفظ التعديلات في CreateEditTaskScreen.kt، يتم استدعاء cancelAlarmsForTask(taskId) أولاً ثم scheduleNextAlarm بالقيم الجديدة.`;
      }

      setTestResults(prev => ({
        ...prev,
        [test.id]: { status: 'passed', message: resultMsg, timestamp: new Date().toLocaleTimeString('ar-SA') }
      }));
      setActiveTestId(null);
    }, 450);
  };

  const runAllTests = () => {
    TEST_CASES.forEach((test, idx) => {
      setTimeout(() => {
        runTest(test);
      }, idx * 250);
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 flex items-center justify-center">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-xl text-slate-900 dark:text-white">
                🧪 مختبر التحقق والاختبار (TEST 1 - TEST 9)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                اختبار الحالات التسع المطلوبة للتحقق من سلامة التعاقب والإشعارات وإلغائها
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          <div className="flex items-center justify-between bg-purple-50 dark:bg-purple-950/30 p-4 rounded-2xl border border-purple-200 dark:border-purple-900/50">
            <div>
              <span className="text-xs font-bold text-purple-900 dark:text-purple-200 block">
                مختبر فحص السلوك التلقائي
              </span>
              <span className="text-[11px] text-purple-700 dark:text-purple-300">
                يمكنك تشغيل كل حالة على حدة أو تشغيل جميع الاختبارات بضغطة زر.
              </span>
            </div>
            <button
              onClick={runAllTests}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-700 text-white shadow-sm transition-all"
            >
              تشغيل جميع الاختبارات (1-9)
            </button>
          </div>

          <div className="space-y-3">
            {TEST_CASES.map(test => {
              const result = testResults[test.id];
              const isRunning = activeTestId === test.id;

              return (
                <div 
                  key={test.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-sm transition-all"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5 flex-1">
                      <span className="w-6 h-6 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {test.number}
                      </span>
                      <div>
                        <h4 className="font-heading font-bold text-sm text-slate-900 dark:text-white">
                          {test.title}
                        </h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                          {test.description}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => runTest(test)}
                      disabled={isRunning}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-600 transition-colors shrink-0 flex items-center gap-1"
                    >
                      <Play className="w-3 h-3 text-emerald-600" />
                      <span>{isRunning ? 'جاري الفحص...' : 'فحص'}</span>
                    </button>
                  </div>

                  {result && (
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-700/60 text-xs">
                      <div className="flex items-start gap-2 text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 p-3 rounded-xl border border-emerald-200 dark:border-emerald-800">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <p className="font-medium">{result.message}</p>
                          <span className="text-[10px] text-emerald-600/70 block mt-1 font-mono">
                            تم التحقق في: {result.timestamp}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white transition-colors"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};

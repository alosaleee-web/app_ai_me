import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  ArrowUp, 
  ArrowDown, 
  Bell, 
  Volume2, 
  Vibrate, 
  Check, 
  Clock, 
  Calendar,
  Sparkles
} from 'lucide-react';
import { TaskItem, TaskType, AlertCountType, Person } from '../types';

interface TaskFormModalProps {
  initialTask?: TaskItem | null;
  people: Person[];
  onSave: (task: TaskItem) => void;
  onClose: () => void;
  onAddNewPerson: (name: string) => Person;
}

const COMMON_ICONS = ['💧', '🧹', '🗑️', '🛒', '🍳', '🚗', '🪴', '📦', '🧴', '☕', '🧺', '🐾', '🔑', '🍞', '💡'];

const START_AFTER_PRESETS = [
  { label: '15 دقيقة', value: 15 },
  { label: '30 دقيقة', value: 30 },
  { label: '1 ساعة', value: 60 },
  { label: '2 ساعة', value: 120 },
  { label: '3 ساعات', value: 180 },
];

const REPEAT_INTERVAL_PRESETS = [
  { label: '5 دقائق', value: 5 },
  { label: '10 دقائق', value: 10 },
  { label: '15 دقيقة', value: 15 },
  { label: '30 دقيقة', value: 30 },
  { label: '1 ساعة', value: 60 },
  { label: '2 ساعة', value: 120 },
];

export const TaskFormModal: React.FC<TaskFormModalProps> = ({
  initialTask,
  people,
  onSave,
  onClose,
  onAddNewPerson
}) => {
  const [title, setTitle] = useState(initialTask?.title || '');
  const [icon, setIcon] = useState(initialTask?.icon || '💧');
  const [type, setType] = useState<TaskType>(initialTask?.type || 'ON_COMPLETE');
  const [intervalDays, setIntervalDays] = useState(initialTask?.intervalDays || 2);
  const [weeklyDay, setWeeklyDay] = useState(initialTask?.weeklyDay ?? 5); // الجمعة
  
  // Ordered person IDs in this task
  const [taskPersonIds, setTaskPersonIds] = useState<string[]>(
    initialTask?.personIds || (people.length > 0 ? people.map(p => p.id) : [])
  );
  const [starterPersonIndex, setStarterPersonIndex] = useState<number>(
    initialTask?.currentPersonIndex || 0
  );

  // Notification Config
  const [notificationsEnabled, setNotificationsEnabled] = useState(
    initialTask?.notifications.enabled ?? true
  );
  const [startAfterMinutes, setStartAfterMinutes] = useState(
    initialTask?.notifications.startAfterMinutes ?? 120
  );
  const [isCustomStartAfter, setIsCustomStartAfter] = useState(false);
  const [customStartAfterInput, setCustomStartAfterInput] = useState('120');

  const [repeatIntervalMinutes, setRepeatIntervalMinutes] = useState(
    initialTask?.notifications.repeatIntervalMinutes ?? 30
  );
  const [isCustomRepeat, setIsCustomRepeat] = useState(false);
  const [customRepeatInput, setCustomRepeatInput] = useState('30');

  const [alertCountType, setAlertCountType] = useState<AlertCountType>(
    initialTask?.notifications.countType || 'UNTIL_COMPLETED'
  );
  const [maxAlertsCount, setMaxAlertsCount] = useState<number>(
    initialTask?.notifications.maxAlertsCount || 3
  );

  const [sound, setSound] = useState(initialTask?.notifications.sound ?? true);
  const [vibrate, setVibrate] = useState(initialTask?.notifications.vibrate ?? true);

  // Quick add inline person
  const [inlinePersonName, setInlinePersonName] = useState('');

  const handleAddInlinePerson = () => {
    if (!inlinePersonName.trim()) return;
    const newP = onAddNewPerson(inlinePersonName.trim());
    setTaskPersonIds(prev => [...prev, newP.id]);
    setInlinePersonName('');
  };

  const movePerson = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= taskPersonIds.length) return;
    const updated = [...taskPersonIds];
    const temp = updated[index];
    updated[index] = updated[targetIndex];
    updated[targetIndex] = temp;
    setTaskPersonIds(updated);
  };

  const removePersonFromTask = (id: string) => {
    setTaskPersonIds(prev => prev.filter(pid => pid !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('يرجى كتابة اسم المهمة');
      return;
    }
    if (taskPersonIds.length === 0) {
      alert('يرجى تحديد شخص واحد على الأقل للمهمة');
      return;
    }

    const startMinutes = isCustomStartAfter ? (parseInt(customStartAfterInput) || 120) : startAfterMinutes;
    const repeatMinutes = isCustomRepeat ? (parseInt(customRepeatInput) || 30) : repeatIntervalMinutes;

    const taskData: TaskItem = {
      id: initialTask?.id || 'task_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: title.trim(),
      icon,
      type,
      status: initialTask?.status || 'ACTIVE',
      personIds: taskPersonIds,
      currentPersonIndex: Math.min(starterPersonIndex, Math.max(0, taskPersonIds.length - 1)),
      intervalDays: type === 'EVERY_X_DAYS' ? intervalDays : undefined,
      weeklyDay: type === 'WEEKLY' ? weeklyDay : undefined,
      turnStartedAt: initialTask?.turnStartedAt || new Date().toISOString(),
      completedForCurrentCycle: initialTask?.completedForCurrentCycle || false,
      notifications: {
        enabled: notificationsEnabled,
        startAfterMinutes: startMinutes,
        repeatIntervalMinutes: repeatMinutes,
        countType: alertCountType,
        maxAlertsCount,
        sound,
        vibrate
      },
      createdAt: initialTask?.createdAt || new Date().toISOString()
    };

    onSave(taskData);
    onClose();
  };

  const peopleMap = new Map<string, Person>(people.map(p => [p.id, p]));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40">
          <div>
            <h2 className="font-heading font-bold text-xl text-slate-900 dark:text-white">
              {initialTask ? 'تعديل المهمة' : '＋ إضافة مهمة جديدة'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              حدد اسم المهمة والأشخاص وطريقة التعاقب والتنبيهات
            </p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Task Name & Icon */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              اسم المهمة والأيقونة:
            </label>
            <div className="flex items-center gap-2">
              <div className="relative">
                <span className="text-2xl p-2.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 inline-block">
                  {icon}
                </span>
              </div>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: تعبئة الماء أو تنظيف المكان"
                required
                className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            {/* Quick Icon Selector */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              {COMMON_ICONS.map(ic => (
                <button
                  type="button"
                  key={ic}
                  onClick={() => setIcon(ic)}
                  className={`w-8 h-8 rounded-lg text-base flex items-center justify-center transition-all ${
                    icon === ic
                      ? 'bg-emerald-100 dark:bg-emerald-950 border-2 border-emerald-500 scale-110'
                      : 'bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {ic}
                </button>
              ))}
            </div>
          </div>

          {/* Task Type */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              نوع المهمة وطريقة انتقال الدور:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setType('ON_COMPLETE')}
                className={`p-3 rounded-xl border text-right transition-all ${
                  type === 'ON_COMPLETE'
                    ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 text-emerald-900 dark:text-emerald-200 ring-1 ring-emerald-500'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <span className="block font-bold text-xs">عند إنجاز المهمة</span>
                <span className="text-[11px] text-slate-500 block mt-0.5">ينتقل فورًا للشخص التالي بمجرد الضغط</span>
              </button>

              <button
                type="button"
                onClick={() => setType('DAILY')}
                className={`p-3 rounded-xl border text-right transition-all ${
                  type === 'DAILY'
                    ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 text-emerald-900 dark:text-emerald-200 ring-1 ring-emerald-500'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <span className="block font-bold text-xs">يومي</span>
                <span className="text-[11px] text-slate-500 block mt-0.5">شخص كل يوم، لا ينتقل في نفس اليوم</span>
              </button>

              <button
                type="button"
                onClick={() => setType('EVERY_X_DAYS')}
                className={`p-3 rounded-xl border text-right transition-all ${
                  type === 'EVERY_X_DAYS'
                    ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 text-emerald-900 dark:text-emerald-200 ring-1 ring-emerald-500'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <span className="block font-bold text-xs">كل X أيام</span>
                <span className="text-[11px] text-slate-500 block mt-0.5">مثال: كل يومين أو 3 أيام</span>
              </button>
            </div>

            {/* X Days configuration if chosen */}
            {type === 'EVERY_X_DAYS' && (
              <div className="mt-2 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  عدد الأيام لكل دور:
                </span>
                <div className="flex items-center gap-2">
                  {[2, 3, 5, 7].map(num => (
                    <button
                      type="button"
                      key={num}
                      onClick={() => setIntervalDays(num)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold ${
                        intervalDays === num
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-600'
                      }`}
                    >
                      {num} أيام
                    </button>
                  ))}
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={intervalDays}
                    onChange={(e) => setIntervalDays(parseInt(e.target.value) || 2)}
                    className="w-16 px-2 py-1 text-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-700 text-xs font-bold"
                  />
                </div>
              </div>
            )}
          </div>

          {/* People & Rotation Order */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                الأشخاص وترتيب الدور ({taskPersonIds.length}):
              </label>
              <span className="text-[11px] text-slate-500">
                الترتيب مهم جدًا للدور الدائري
              </span>
            </div>

            {/* Quick add person input */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={inlinePersonName}
                onChange={(e) => setInlinePersonName(e.target.value)}
                placeholder="إضافة شخص جديد للقائمة (مثال: صالح)"
                className="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddInlinePerson();
                  }
                }}
              />
              <button
                type="button"
                onClick={handleAddInlinePerson}
                className="px-3 py-2 rounded-xl text-xs font-bold bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-white"
              >
                ＋ إضافة
              </button>
            </div>

            {/* People list with reorder buttons */}
            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {taskPersonIds.map((pid, index) => {
                const person = peopleMap.get(pid);
                const isStarter = starterPersonIndex === index;

                return (
                  <div 
                    key={pid}
                    className={`flex items-center justify-between p-2.5 rounded-xl border text-xs transition-all ${
                      isStarter
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800'
                        : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-400 w-4 text-center">
                        {index + 1}.
                      </span>
                      <span className="font-bold text-slate-800 dark:text-slate-100">
                        {person ? person.name : 'شخص محذوف'}
                      </span>
                      {isStarter && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-600 text-white">
                          يبدأ منه الدور
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1">
                      {/* Set as starter button */}
                      <button
                        type="button"
                        onClick={() => setStarterPersonIndex(index)}
                        className={`px-2 py-1 rounded-lg text-[10px] font-semibold border ${
                          isStarter
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-slate-50 dark:bg-slate-700 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-600'
                        }`}
                      >
                        يبدأ الدور
                      </button>

                      {/* Move up */}
                      <button
                        type="button"
                        onClick={() => movePerson(index, 'up')}
                        disabled={index === 0}
                        className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-30"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>

                      {/* Move down */}
                      <button
                        type="button"
                        onClick={() => movePerson(index, 'down')}
                        disabled={index === taskPersonIds.length - 1}
                        className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-30"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>

                      {/* Remove from task */}
                      <button
                        type="button"
                        onClick={() => removePersonFromTask(pid)}
                        className="p-1 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-950"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Notifications Section */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-4">
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  إعدادات التنبيهات الخاصة بالمهمة
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationsEnabled}
                  onChange={(e) => setNotificationsEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>

            {notificationsEnabled && (
              <div className="space-y-4 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                
                {/* Start alert after */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    ابدأ إرسال التذكيرات بعد:
                  </label>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {START_AFTER_PRESETS.map(preset => (
                      <button
                        type="button"
                        key={preset.value}
                        onClick={() => {
                          setStartAfterMinutes(preset.value);
                          setIsCustomStartAfter(false);
                        }}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          !isCustomStartAfter && startAfterMinutes === preset.value
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setIsCustomStartAfter(true)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border ${
                        isCustomStartAfter
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      مخصص
                    </button>
                  </div>
                  {isCustomStartAfter && (
                    <div className="flex items-center gap-2 mt-2">
                      <input
                        type="number"
                        min="1"
                        value={customStartAfterInput}
                        onChange={(e) => setCustomStartAfterInput(e.target.value)}
                        placeholder="بالدقائق"
                        className="w-24 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                      />
                      <span className="text-xs text-slate-500">دقيقة</span>
                    </div>
                  )}
                </div>

                {/* Repeat every */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    كرر التنبيه كل:
                  </label>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {REPEAT_INTERVAL_PRESETS.map(preset => (
                      <button
                        type="button"
                        key={preset.value}
                        onClick={() => {
                          setRepeatIntervalMinutes(preset.value);
                          setIsCustomRepeat(false);
                        }}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          !isCustomRepeat && repeatIntervalMinutes === preset.value
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setIsCustomRepeat(true)}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border ${
                        isCustomRepeat
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      مخصص
                    </button>
                  </div>
                  {isCustomRepeat && (
                    <div className="flex items-center gap-2 mt-2">
                      <input
                        type="number"
                        min="1"
                        value={customRepeatInput}
                        onChange={(e) => setCustomRepeatInput(e.target.value)}
                        placeholder="بالدقائق"
                        className="w-24 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                      />
                      <span className="text-xs text-slate-500">دقيقة</span>
                    </div>
                  )}
                </div>

                {/* Number of alerts: 2 options only */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    عدد التنبيهات:
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setAlertCountType('UNTIL_COMPLETED')}
                      className={`p-2.5 rounded-xl border text-center text-xs font-bold ${
                        alertCountType === 'UNTIL_COMPLETED'
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      1. حتى إنجاز المهمة
                    </button>

                    <button
                      type="button"
                      onClick={() => setAlertCountType('EXACT_COUNT')}
                      className={`p-2.5 rounded-xl border text-center text-xs font-bold ${
                        alertCountType === 'EXACT_COUNT'
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      2. عدد محدد
                    </button>
                  </div>

                  {alertCountType === 'EXACT_COUNT' && (
                    <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                      {[1, 2, 3, 4, 5, 10].map(count => (
                        <button
                          type="button"
                          key={count}
                          onClick={() => setMaxAlertsCount(count)}
                          className={`w-9 h-8 rounded-lg text-xs font-bold border ${
                            maxAlertsCount === count
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {count}
                        </button>
                      ))}
                      <input
                        type="number"
                        min="1"
                        max="99"
                        value={maxAlertsCount}
                        onChange={(e) => setMaxAlertsCount(parseInt(e.target.value) || 1)}
                        className="w-16 px-2 py-1 text-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                      />
                    </div>
                  )}
                </div>

                {/* Sound & Vibration toggles */}
                <div className="flex items-center gap-4 pt-1">
                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sound}
                      onChange={(e) => setSound(e.target.checked)}
                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                    />
                    <span>صوت الإشعار</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={vibrate}
                      onChange={(e) => setVibrate(e.target.checked)}
                      className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                    />
                    <span>الاهتزاز</span>
                  </label>
                </div>

              </div>
            )}

          </div>

          {/* Submit */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 px-6 rounded-2xl font-heading font-extrabold text-base bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              <Check className="w-5 h-5" />
              <span>{initialTask ? 'حفظ التعديلات' : 'حفظ المهمة'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

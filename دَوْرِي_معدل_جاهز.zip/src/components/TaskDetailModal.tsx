import React from 'react';
import { 
  X, 
  CheckCircle2, 
  Clock, 
  Bell, 
  Edit3, 
  Trash2, 
  Pause, 
  Play, 
  Calendar, 
  History, 
  User, 
  Volume2, 
  Vibrate, 
  AlertCircle 
} from 'lucide-react';
import { TaskItem, Person, TaskLog } from '../types';
import { calculateNextAlert, getTaskTypeLabel } from '../utils/rotationLogic';

interface TaskDetailModalProps {
  task: TaskItem;
  people: Person[];
  logs: TaskLog[];
  onClose: () => void;
  onComplete: (task: TaskItem) => void;
  onEdit: (task: TaskItem) => void;
  onDelete: (taskId: string) => void;
  onTogglePause: (task: TaskItem) => void;
  now: Date;
}

export const TaskDetailModal: React.FC<TaskDetailModalProps> = ({
  task,
  people,
  logs,
  onClose,
  onComplete,
  onEdit,
  onDelete,
  onTogglePause,
  now
}) => {
  const peopleMap = new Map<string, Person>(people.map(p => [p.id, p]));
  const currentPersonId = task.personIds[task.currentPersonIndex];
  const currentPerson = peopleMap.get(currentPersonId);
  const nextAlert = calculateNextAlert(task, now);

  const orderedMembers = task.personIds.map(id => peopleMap.get(id)).filter(Boolean) as Person[];
  const taskLogs = logs.filter(l => l.taskId === task.id);

  const isPaused = task.status === 'PAUSED';

  // Format log timestamp
  const formatLogDate = (isoStr: string) => {
    const d = new Date(isoStr);
    const today = new Date();
    const isSameDay = d.toDateString() === today.toDateString();
    
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const isYesterday = d.toDateString() === yesterday.toDateString();

    const timeStr = d.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });

    if (isSameDay) return `اليوم — ${timeStr}`;
    if (isYesterday) return `أمس — ${timeStr}`;
    return `${d.toLocaleDateString('ar-SA')} — ${timeStr}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{task.icon}</span>
            <div>
              <h2 className="font-heading font-bold text-xl text-slate-900 dark:text-white">
                {task.title}
              </h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                {getTaskTypeLabel(task.type, task.intervalDays)}
              </span>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Current Turn Hero Card */}
          <div className="bg-gradient-to-br from-emerald-500/10 via-emerald-500/5 to-teal-500/10 dark:from-emerald-950/40 dark:to-slate-800 p-4 sm:p-5 rounded-2xl border border-emerald-200 dark:border-emerald-800/60">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  الشخص الذي عليه الدور الآن:
                </span>
                <div className="flex items-center gap-2 mt-1">
                  <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-base shadow-sm">
                    {currentPerson ? currentPerson.name.charAt(0) : '?'}
                  </div>
                  <div>
                    <h3 className="text-lg font-heading font-extrabold text-emerald-800 dark:text-emerald-300">
                      {currentPerson ? currentPerson.name : 'غير محدد'}
                    </h3>
                    <span className="text-xs text-slate-600 dark:text-slate-400">
                      {isPaused ? 'المهمة متوقفة مؤقتًا' : task.completedForCurrentCycle ? 'تم الإنجاز لهذه الدورة' : 'قيد الانتظار للتنفيذ'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Status pill */}
              <div className="text-left">
                <span className={`inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl ${
                  isPaused
                    ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200 border border-amber-300'
                    : 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-700'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${isPaused ? 'bg-amber-500' : 'bg-emerald-500 animate-pulse'}`} />
                  {isPaused ? 'متوقفة' : 'نشطة'}
                </span>
              </div>
            </div>

            {/* Countdown timer if applicable */}
            {task.notifications.enabled && !isPaused && (
              <div className="mt-4 pt-3 border-t border-emerald-200/50 dark:border-emerald-800/40 flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                  <Clock className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>{nextAlert.label}:</span>
                </div>
                {nextAlert.formattedCountdown ? (
                  <span className="font-mono font-extrabold text-base text-emerald-700 dark:text-emerald-300 bg-white dark:bg-slate-800 px-3 py-1 rounded-xl border border-emerald-200 dark:border-emerald-700 shadow-sm dir-ltr">
                    {nextAlert.formattedCountdown}
                  </span>
                ) : (
                  <span className="text-xs text-slate-500">{nextAlert.label}</span>
                )}
              </div>
            )}
          </div>

          {/* Big Action Button: تم الإنجاز */}
          <div>
            <button
              onClick={() => {
                onComplete(task);
              }}
              disabled={isPaused}
              className="w-full py-3.5 px-6 rounded-2xl font-heading font-extrabold text-base bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2.5 transition-all duration-150 active:scale-[0.98] disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed"
            >
              <CheckCircle2 className="w-6 h-6" />
              <span>✅ تم الإنجاز (انتقال الدور للشخص التالي)</span>
            </button>
            <p className="text-[11px] text-center text-slate-500 dark:text-slate-400 mt-2">
              عند الضغط، يتم تسجيل الإنجاز وإلغاء تنبيهات الشخص الحالي وبدء عداد التنبيهات للشخص التالي من البداية.
            </p>
          </div>

          {/* Persons Circular Order */}
          <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800">
            <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2.5">
              ترتيب تعاقب الأدوار (الدور الدائري)
            </h4>
            <div className="flex items-center gap-2 flex-wrap">
              {orderedMembers.map((member, idx) => {
                const isCurrent = idx === task.currentPersonIndex;
                return (
                  <React.Fragment key={member.id}>
                    <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-medium text-xs transition-all ${
                      isCurrent
                        ? 'bg-emerald-600 text-white border-emerald-600 font-bold shadow-sm'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}>
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: isCurrent ? '#ffffff' : member.avatarColor }} />
                      <span>{member.name}</span>
                      {isCurrent && <span className="text-[10px] bg-emerald-700 px-1.5 py-0.5 rounded-full">الآن</span>}
                    </div>
                    {idx < orderedMembers.length - 1 && (
                      <span className="text-slate-400 dark:text-slate-600 font-bold">←</span>
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>

          {/* Notification Rules Overview */}
          <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
            <h4 className="font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              إعدادات نظام التنبيهات
            </h4>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200/70 dark:border-slate-700/70">
                <span className="text-slate-500 block text-[11px]">أول تنبيه:</span>
                <span className="font-bold">بعد {task.notifications.startAfterMinutes} دقيقة</span>
              </div>
              <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200/70 dark:border-slate-700/70">
                <span className="text-slate-500 block text-[11px]">فاصل التكرار:</span>
                <span className="font-bold">كل {task.notifications.repeatIntervalMinutes} دقيقة</span>
              </div>
              <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200/70 dark:border-slate-700/70">
                <span className="text-slate-500 block text-[11px]">عدد التنبيهات:</span>
                <span className="font-bold">
                  {task.notifications.countType === 'UNTIL_COMPLETED'
                    ? 'حتى إنجاز المهمة'
                    : `${task.notifications.maxAlertsCount} تنبيهات كحد أقصى`}
                </span>
              </div>
              <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200/70 dark:border-slate-700/70">
                <span className="text-slate-500 block text-[11px]">الصوت والاهتزاز:</span>
                <span className="font-bold">
                  {task.notifications.sound ? 'صوت مفعل' : 'صامت'} • {task.notifications.vibrate ? 'اهتزاز' : 'بدون'}
                </span>
              </div>
            </div>
          </div>

          {/* History Logs */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <History className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <h4 className="font-heading font-bold text-sm text-slate-900 dark:text-white">
                سجل الإنجازات السابق
              </h4>
            </div>

            {taskLogs.length === 0 ? (
              <div className="text-center py-6 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-500">
                لا توجد إنجازات مسجلة لهذه المهمة حتى الآن.
              </div>
            ) : (
              <div className="space-y-2">
                {taskLogs.slice(0, 8).map(log => (
                  <div 
                    key={log.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/70 dark:border-slate-700/70 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold text-[11px]">
                        ✓
                      </div>
                      <div>
                        <span className="font-bold text-slate-800 dark:text-slate-100">
                          {log.personName}
                        </span>
                        <span className="text-slate-500 mx-1.5">—</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-medium">تم الإنجاز</span>
                      </div>
                    </div>
                    <span className="text-slate-400 font-mono text-[11px] dir-ltr">
                      {formatLogDate(log.completedAt)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Controls footer */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
            <button
              onClick={() => onTogglePause(task)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                isPaused
                  ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200'
                  : 'bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200'
              }`}
            >
              {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
              <span>{isPaused ? 'استئناف التنبيهات' : 'إيقاف مؤقت'}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onEdit(task)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>تعديل</span>
              </button>

              <button
                onClick={() => {
                  if (confirm(`هل أنت متأكد من حذف مهمة "${task.title}"؟ سيتم إلغاء كافة التنبيهات المجدولة.`)) {
                    onDelete(task.id);
                    onClose();
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-red-50 dark:bg-red-950/50 hover:bg-red-100 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-900 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

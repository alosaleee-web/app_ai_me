import React, { useState } from 'react';
import { 
  X, 
  Smartphone, 
  Download, 
  Copy, 
  Check, 
  ExternalLink, 
  Chrome, 
  Sparkles, 
  Share2,
  Terminal
} from 'lucide-react';
import { generateAndroidProjectZip, triggerDownload } from '../utils/zipGenerator';

interface InstallPhoneModalProps {
  onClose: () => void;
  deferredPrompt?: any;
}

export const InstallPhoneModal: React.FC<InstallPhoneModalProps> = ({ onClose, deferredPrompt }) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  // App URLs
  const appUrl = window.location.origin;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handlePromptInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        onClose();
      }
    } else {
      handleCopyLink();
    }
  };

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      const blob = await generateAndroidProjectZip();
      triggerDownload(blob, 'dawri-android-project.zip');
    } catch {
      alert('حدث خطأ أثناء تحميل الملف، يرجى المحاولة مرة أخرى.');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-emerald-600/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg sm:text-xl text-slate-900 dark:text-white">
                📲 تثبيت وتشغيل «دَوْرِي» على هاتفك الآن
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                لديك خياران متاحان لتشغيل التطبيق على هاتفك المحمول فورًا
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Method 1: Instant Install (No PC required, 10 seconds) */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-500/10 via-emerald-500/5 to-teal-500/10 dark:from-emerald-950/40 dark:to-slate-800 border-2 border-emerald-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shadow-sm">
                  1
                </span>
                <h3 className="font-heading font-bold text-base text-emerald-900 dark:text-emerald-200">
                  الطريقة الفورية: التثبيت المباشر على الهاتف (PWA)
                </h3>
              </div>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-200/60 dark:bg-emerald-800/60 text-emerald-800 dark:text-emerald-200">
                أسرع طريقة ⚡
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              افتح هذا الرابط على متصفح <strong>Google Chrome</strong> في هاتفك وثبّت التطبيق بضغطة واحدة ليتحول إلى تطبيق مستقل على شاشتك الرئيسية يعمل 100% بدون إنترنت مع الإشعارات:
            </p>

            {/* URL Box */}
            <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono text-xs dir-ltr">
              <span className="truncate text-slate-700 dark:text-slate-300 select-all">
                {appUrl}
              </span>
              <button
                onClick={handleCopyLink}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-bold shrink-0 flex items-center gap-1 shadow-sm transition-all"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'تم النسخ!' : 'نسخ الرابط'}</span>
              </button>
            </div>

            {/* Android Chrome Instructions */}
            <div className="bg-white/80 dark:bg-slate-900/80 p-3 rounded-xl border border-slate-200/80 dark:border-slate-800 space-y-2 text-xs text-slate-700 dark:text-slate-300">
              <div className="flex items-start gap-2">
                <span className="font-bold text-emerald-600">أ.</span>
                <span>افتح الرابط في متصفح <strong>Chrome</strong> على هاتف الأندرويد.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-emerald-600">ب.</span>
                <span>اضغط على قائمة الخيارات (الثلاث نقاط <strong>⋮</strong>) في أعلى الزاوية.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-emerald-600">ج.</span>
                <span>اختر <strong>«تثبيت التطبيق» (Install App)</strong> أو <strong>«الإضافة إلى الشاشة الرئيسية»</strong>.</span>
              </div>
            </div>

            {deferredPrompt && (
              <button
                onClick={handlePromptInstall}
                className="w-full py-2.5 px-4 rounded-xl font-heading font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all active:scale-98"
              >
                <Smartphone className="w-4 h-4" />
                <span>اضغط هنا لتثبيت التطبيق على جهازك الآن</span>
              </button>
            )}
          </div>

          {/* Method 2: Native APK (Kotlin / Android Studio) */}
          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-slate-700 text-white font-bold text-xs flex items-center justify-center">
                  2
                </span>
                <h3 className="font-heading font-bold text-base text-slate-900 dark:text-white">
                  طريقة ملف الـ APK الأصلي (Native Android Studio)
                </h3>
              </div>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                مشروع كامل 📦
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              إذا كنت تفضل بناء ملف APK الأصلي المترجم من كود Kotlin مباشرة عبر Android Studio:
            </p>

            <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex items-center gap-2">
                <span>1. حمّل حزمة المشروع المفحوصة والخالية من الأخطاء:</span>
              </div>
              <button
                onClick={handleDownloadZip}
                disabled={isDownloading}
                className="w-full py-2.5 px-4 rounded-xl font-heading font-bold text-xs bg-slate-800 hover:bg-slate-900 text-white flex items-center justify-center gap-2 transition-all active:scale-98"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>{isDownloading ? 'جاري تجهيز الملف...' : 'تحميل مشروع Android كامل (ZIP)'}</span>
              </button>
            </div>

            <div className="text-[11px] text-slate-500 dark:text-slate-400 space-y-1 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
              <p>2. افتح المجلد في Android Studio واضغط <strong>Build &gt; Build APK(s)</strong>.</p>
              <p>3. انقل ملف <code>app-debug.apk</code> إلى هاتفك عبر واتساب أو تيليجرام أو الكابل وثبته فورًا.</p>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white transition-colors"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};

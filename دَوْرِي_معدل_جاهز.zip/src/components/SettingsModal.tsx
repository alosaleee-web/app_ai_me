import React from 'react';
import { 
  X, 
  Sun, 
  Moon, 
  Laptop, 
  Bell, 
  Volume2, 
  Vibrate, 
  Download, 
  Users, 
  RotateCcw, 
  ShieldCheck, 
  Smartphone,
  Palette
} from 'lucide-react';
import { UserSettings } from '../types';

interface SettingsModalProps {
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onClose: () => void;
  onOpenPersons: () => void;
  onOpenDownload: () => void;
  onResetData: () => void;
}

const ACCENT_COLORS = [
  { name: 'زمردي (افتراضي)', key: 'emerald', bg: 'bg-emerald-600' },
  { name: 'نيلي ملكي', key: 'indigo', bg: 'bg-indigo-600' },
  { name: 'عنبري دافئ', key: 'amber', bg: 'bg-amber-600' },
  { name: 'وردي أنيق', key: 'rose', bg: 'bg-rose-600' },
  { name: 'أزرق سماوي', key: 'sky', bg: 'bg-sky-600' }
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
  onOpenPersons,
  onOpenDownload,
  onResetData
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40">
          <div>
            <h2 className="font-heading font-bold text-xl text-slate-900 dark:text-white">
              ⚙️ الإعدادات العامة
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              تخصيص المظهر والتنبيهات وإدارة البيانات المحلية
            </p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Theme Mode */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              مظهر التطبيق (Dark / Light Mode):
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => onUpdateSettings({ theme: 'light' })}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all ${
                  settings.theme === 'light'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-200 ring-1 ring-emerald-500 font-bold'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Sun className="w-5 h-5 text-amber-500" />
                <span className="text-xs">☀️ فاتح</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings({ theme: 'dark' })}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all ${
                  settings.theme === 'dark'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-200 ring-1 ring-emerald-500 font-bold'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Moon className="w-5 h-5 text-indigo-400" />
                <span className="text-xs">🌙 داكن</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings({ theme: 'system' })}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-1.5 transition-all ${
                  settings.theme === 'system'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-200 ring-1 ring-emerald-500 font-bold'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Laptop className="w-5 h-5 text-slate-500" />
                <span className="text-xs">⚙️ تلقائي</span>
              </button>
            </div>
          </div>

          {/* Master Notifications & Audio */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-4">
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">
              التنبيهات والأصوات العامة
            </h3>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                    تشغيل التنبيهات
                  </span>
                  <span className="text-[11px] text-slate-500">
                    تفعيل أو إيقاف إرسال الإشعارات والتذكيرات
                  </span>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.notificationsEnabled}
                  onChange={(e) => onUpdateSettings({ notificationsEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-300 rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                    صوت التنبيه
                  </span>
                  <span className="text-[11px] text-slate-500">
                    تشغيل نغمة لطيفة عند حان الدور وعند التذكير
                  </span>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.soundEnabled}
                  onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-300 rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
              <div className="flex items-center gap-2">
                <Vibrate className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block">
                    الاهتزاز
                  </span>
                  <span className="text-[11px] text-slate-500">
                    نمط اهتزاز خفيف لتنبيهك
                  </span>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.vibrationEnabled}
                  onChange={(e) => onUpdateSettings({ vibrationEnabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-300 rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
              إدارة سريعة
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onClose();
                  onOpenPersons();
                }}
                className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200 transition-colors"
              >
                <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>إدارة الأشخاص</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenDownload();
                }}
                className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200 transition-colors"
              >
                <Smartphone className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>مشروع Android Native</span>
              </button>
            </div>
          </div>

          {/* Privacy info */}
          <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-xs space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-300">
              <ShieldCheck className="w-4 h-4" />
              <span>خصوصية 100% - محلي بالكامل</span>
            </div>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]">
              تطبيق «دَوْرِي» لا يجمع أي بيانات، ولا يحتاج إلى حساب، ولا رقم هاتف، ولا إنترنت. كل شيء محفوظ محليًا على جهازك فقط.
            </p>
          </div>

          {/* Reset Demo Data */}
          <div className="pt-2">
            <button
              onClick={() => {
                if (confirm('هل تريد إعادة تعيين كافة البيانات إلى الحالة الافتراضية التجريبية؟')) {
                  onResetData();
                  onClose();
                }
              }}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-slate-500 hover:text-red-600 dark:text-slate-400 hover:bg-red-50 dark:hover:bg-red-950/40 border border-transparent hover:border-red-200 transition-all flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة ضبط البيانات إلى الوضع الافتراضي</span>
            </button>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 flex items-center justify-between">
          <span className="text-[11px] text-slate-400 font-mono">
            دَوْرِي v1.0.0 (Native Android)
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 text-white hover:bg-emerald-700 transition-colors shadow-sm"
          >
            حفظ وإغلاق
          </button>
        </div>

      </div>
    </div>
  );
};

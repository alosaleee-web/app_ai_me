import React from 'react';
import { 
  Plus, 
  Users, 
  Settings as SettingsIcon, 
  Download, 
  FlaskConical, 
  Bell, 
  BellOff, 
  UserCheck 
} from 'lucide-react';
import { Person } from '../types';

interface HeaderProps {
  people: Person[];
  currentUserId: string;
  onSelectUser: (userId: string) => void;
  onOpenCreateTask: () => void;
  onOpenPersons: () => void;
  onOpenSettings: () => void;
  onOpenTests: () => void;
  onOpenDownload: () => void;
  notificationsEnabled: boolean;
  onRequestNotificationPermission: () => void;
  activeColor: string;
}

export const Header: React.FC<HeaderProps> = ({
  people,
  currentUserId,
  onSelectUser,
  onOpenCreateTask,
  onOpenPersons,
  onOpenSettings,
  onOpenTests,
  onOpenDownload,
  notificationsEnabled,
  onRequestNotificationPermission,
  activeColor
}) => {
  const currentUser = people.find(p => p.id === currentUserId);

  return (
    <header className="sticky top-0 z-30 backdrop-blur-md bg-white/85 dark:bg-slate-900/85 border-b border-slate-200/80 dark:border-slate-800/80 transition-colors">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex items-center justify-between gap-3">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-white flex items-center justify-center font-heading font-extrabold text-xl shadow-md shadow-emerald-500/20">
              د
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold font-heading text-slate-900 dark:text-white tracking-tight">
                  دَوْرِي
                </h1>
                <span className="hidden sm:inline-flex px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  Android Native + Local
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                نظّم الدور، واترك الباقي علينا.
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            
            {/* Identity Switcher */}
            <div className="relative flex items-center">
              <label 
                htmlFor="user-identity-select" 
                className="hidden md:flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer"
              >
                <UserCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>أنت:</span>
                <select
                  id="user-identity-select"
                  value={currentUserId}
                  onChange={(e) => onSelectUser(e.target.value)}
                  className="bg-transparent font-bold text-slate-900 dark:text-white focus:outline-none cursor-pointer"
                >
                  <option value="ALL">عرض الكل</option>
                  {people.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {/* Notification Permission Indicator */}
            <button
              onClick={onRequestNotificationPermission}
              title={notificationsEnabled ? 'الإشعارات مفعلة' : 'اضغط لتفعيل إشعارات المتصفح'}
              className={`p-2 rounded-xl border transition-colors ${
                notificationsEnabled
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800'
                  : 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800'
              }`}
            >
              {notificationsEnabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
            </button>

            {/* Test Laboratory Button */}
            <button
              onClick={onOpenTests}
              title="مختبر الاختبارات التسعة (TEST 1 - TEST 9)"
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 hover:bg-purple-100 transition-colors"
            >
              <FlaskConical className="w-4 h-4" />
              <span>مختبر الاختبارات</span>
            </button>

            {/* Download Android Project Button */}
            <button
              onClick={onOpenDownload}
              title="تحميل كود أندرويد الكامل ومشروع Android Studio (ZIP)"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm shadow-emerald-600/30 transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">تحميل Android (ZIP)</span>
              <span className="sm:hidden">APK</span>
            </button>

            {/* Manage Persons */}
            <button
              onClick={onOpenPersons}
              title="إدارة الأشخاص"
              className="p-2 rounded-xl text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-colors"
            >
              <Users className="w-4 h-4" />
            </button>

            {/* Settings */}
            <button
              onClick={onOpenSettings}
              title="الإعدادات"
              className="p-2 rounded-xl text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-colors"
            >
              <SettingsIcon className="w-4 h-4" />
            </button>

          </div>

        </div>

        {/* Mobile identity selection bar */}
        <div className="md:hidden mt-2 pt-2 border-t border-slate-200/50 dark:border-slate-800/50 flex items-center justify-between text-xs">
          <span className="text-slate-500 dark:text-slate-400">تصفح باسم:</span>
          <select
            value={currentUserId}
            onChange={(e) => onSelectUser(e.target.value)}
            className="bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-lg border border-slate-200 dark:border-slate-700 font-bold text-slate-800 dark:text-white"
          >
            <option value="ALL">جميع الأشخاص (الكل)</option>
            {people.map(p => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>

      </div>
    </header>
  );
};

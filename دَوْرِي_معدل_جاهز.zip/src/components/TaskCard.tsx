import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  Bell, 
  RotateCw, 
  Calendar, 
  AlertCircle,
  Pause,
  ChevronLeft
} from 'lucide-react';
import { TaskItem, Person } from '../types';
import { calculateNextAlert, getTaskTypeLabel } from '../utils/rotationLogic';

interface TaskCardProps {
  task: TaskItem;
  people: Person[];
  isMyTurn: boolean;
  onComplete: (task: TaskItem) => void;
  onClick: (task: TaskItem) => void;
  now: Date;
}

export const TaskCard: React.FC<TaskCardProps> = ({
  task,
  people,
  isMyTurn,
  onComplete,
  onClick,
  now
}) => {
  const peopleMap = new Map<string, Person>(people.map(p => [p.id, p]));
  const currentPersonId = task.personIds[task.currentPersonIndex];
  const currentPerson = peopleMap.get(currentPersonId);
  const nextAlert = calculateNextAlert(task, now);

  const orderedMembers = task.personIds.map(id => peopleMap.get(id)).filter(Boolean) as Person[];

  const isPaused = task.status === 'PAUSED';
  const isDoneToday = task.completedForCurrentCycle;

  return (
    <div 
      className={`relative group rounded-2xl p-4 sm:p-5 transition-all duration-200 border ${
        isMyTurn && !isDoneToday && !isPaused
          ? 'bg-gradient-to-br from-emerald-500/10 via-white to-emerald-500/5 dark:from-emerald-950/40 dark:via-slate-900 dark:to-slate-900 border-emerald-300 dark:border-emerald-700/60 shadow-lg shadow-emerald-500/10'
          : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/70 shadow-sm hover:shadow-md'
      }`}
    >
      {/* Top row: Icon, Title, Status badge & Type */}
      <div className="flex items-start justify-between gap-3">
        <div 
          onClick={() => onClick(task)}
          className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
        >
          <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-700/80 text-2xl flex items-center justify-center shrink-0 shadow-inner">
            {task.icon}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-heading font-bold text-base sm:text-lg text-slate-900 dark:text-white truncate">
                {task.title}
              </h3>
              {isPaused && (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                  <Pause className="w-2.5 h-2.5" />
                  متوقفة
                </span>
              )}
              {isDoneToday && (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-sky-100 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
                  <CheckCircle2 className="w-2.5 h-2.5" />
                  أُنجزت للدورة الحالية
                </span>
              )}
            </div>

            {/* Current Turn Badge */}
            <div className="flex items-center gap-1.5 mt-1 text-xs">
              <span className="text-slate-500 dark:text-slate-400">الدور الحالي:</span>
              <span className={`font-bold px-2 py-0.5 rounded-full text-xs ${
                isMyTurn
                  ? 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-700'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200'
              }`}>
                {currentPerson ? currentPerson.name : 'غير محدد'}
                {isMyTurn && ' (عليك الدور الآن)'}
              </span>
            </div>
          </div>
        </div>

        {/* Task Type badge */}
        <div className="shrink-0 flex items-center gap-1">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700">
            {getTaskTypeLabel(task.type, task.intervalDays)}
          </span>
          <button 
            onClick={() => onClick(task)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            title="عرض التفاصيل"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Rotation sequence trail */}
      <div 
        onClick={() => onClick(task)}
        className="mt-3.5 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center gap-1.5 overflow-x-auto pb-1 text-xs text-slate-500 dark:text-slate-400 cursor-pointer scrollbar-none"
      >
        <span className="text-[11px] font-medium shrink-0 ml-1">ترتيب الدور:</span>
        <div className="flex items-center gap-1">
          {orderedMembers.map((member, idx) => {
            const isCurrent = idx === task.currentPersonIndex;
            return (
              <React.Fragment key={member.id}>
                <span 
                  className={`px-2 py-0.5 rounded-md font-medium shrink-0 transition-all ${
                    isCurrent
                      ? 'bg-emerald-600 text-white font-bold shadow-sm shadow-emerald-600/30'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {member.name}
                </span>
                {idx < orderedMembers.length - 1 && (
                  <span className="text-slate-400 dark:text-slate-600 font-bold shrink-0">←</span>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Countdown and Notification Status */}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs">
        {task.notifications.enabled && !isPaused && !isDoneToday ? (
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 px-2.5 py-1.5 rounded-xl border border-slate-200/60 dark:border-slate-700/60">
            <Clock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{nextAlert.label}:</span>
            {nextAlert.formattedCountdown && (
              <span className="font-mono font-bold text-emerald-700 dark:text-emerald-300 dir-ltr inline-block">
                {nextAlert.formattedCountdown}
              </span>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500 text-[11px]">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>
              {isPaused 
                ? 'التنبيهات متوقفة' 
                : isDoneToday 
                ? 'الدور التالي يبدأ غدًا' 
                : 'التنبيهات معطلة لهذه المهمة'}
            </span>
          </div>
        )}

        {/* Start after & interval summary */}
        {task.notifications.enabled && (
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            فاصل التكرار: {task.notifications.repeatIntervalMinutes} دقيقة
          </div>
        )}
      </div>

      {/* Big Action Button: تم الإنجاز */}
      <div className="mt-4 pt-2">
        <button
          onClick={() => onComplete(task)}
          disabled={isPaused}
          className={`w-full py-2.5 sm:py-3 px-4 rounded-xl font-heading font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-sm transition-all duration-150 active:scale-[0.98] ${
            isPaused
              ? 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
              : isDoneToday
              ? 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700'
              : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/30'
          }`}
        >
          <CheckCircle2 className="w-5 h-5" />
          <span>{isDoneToday ? 'تم الإنجاز اليوم (إعادة إنجاز)' : '✅ تم الإنجاز'}</span>
        </button>
      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { 
  X, 
  Download, 
  CheckCircle2, 
  Smartphone, 
  Terminal, 
  FolderGit2, 
  FileCode2, 
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { generateAndroidProjectZip, triggerDownload } from '../utils/zipGenerator';
import { getAndroidProjectFiles } from '../androidProject/androidCode';

interface DownloadApkModalProps {
  onClose: () => void;
}

export const DownloadApkModal: React.FC<DownloadApkModalProps> = ({ onClose }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [selectedFilePath, setSelectedFilePath] = useState<string>('app/src/main/java/com/dawri/app/notification/AlarmScheduler.kt');

  const files = getAndroidProjectFiles();
  const selectedFile = files.find(f => f.path === selectedFilePath) || files[0];

  const handleDownload = async () => {
    setIsGenerating(true);
    try {
      const blob = await generateAndroidProjectZip();
      triggerDownload(blob, 'dawri-android-project.zip');
    } catch (err) {
      alert('حدث خطأ أثناء تجميع ملف ZIP، يرجى المحاولة مرة أخرى.');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyCommand = () => {
    navigator.clipboard.writeText('./gradlew assembleDebug');
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xl shadow-md shadow-emerald-600/30">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-xl text-slate-900 dark:text-white">
                مشروع Android Native الكامل (APK Ready)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                مشروع Kotlin + Jetpack Compose + Room + AlarmManager جاهز للبناء
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Main Download CTA */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-xl shadow-emerald-600/20 text-center space-y-4">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-sm border border-white/20 text-2xl">
              📦
            </div>
            <div>
              <h3 className="text-xl font-heading font-extrabold tracking-tight">
                تحميل حزمة مشروع Android كاملة بصيغة ZIP
              </h3>
              <p className="text-xs text-emerald-100 max-w-lg mx-auto mt-1.5 leading-relaxed">
                يحتوي على كافة ملفات المصدر (32 ملفًا)، وإعدادات Gradle، وقواعد بيانات Room المحلية، ومنظومة AlarmManager الدقيقة، وترتيب دور المهام.
              </p>
            </div>

            <div>
              <button
                onClick={handleDownload}
                disabled={isGenerating}
                className="px-8 py-3.5 rounded-2xl font-heading font-extrabold text-sm sm:text-base bg-white text-emerald-800 hover:bg-emerald-50 shadow-lg shadow-black/10 transition-all active:scale-95 disabled:opacity-75 flex items-center gap-2.5 mx-auto"
              >
                <Download className="w-5 h-5 text-emerald-600" />
                <span>{isGenerating ? 'جاري ضغط الحزمة وتحضيرها...' : 'تحميل مشروع Android Studio الآن (ZIP)'}</span>
              </button>
            </div>
          </div>

          {/* Quick Steps to Build APK */}
          <div className="space-y-3">
            <h4 className="font-heading font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-600" />
              <span>خطوات بناء ملف APK في دقيقتين عبر Android Studio:</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-1.5">
                <span className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center">
                  1
                </span>
                <h5 className="font-bold text-xs text-slate-800 dark:text-slate-200">فك الضغط والفتح</h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  فك ضغط ملف ZIP المحمل وافتحه في Android Studio عبر خيار <strong>Open</strong>.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-1.5">
                <span className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center">
                  2
                </span>
                <h5 className="font-bold text-xs text-slate-800 dark:text-slate-200">بناء الـ APK بضغطة زر</h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  من القائمة: <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-1.5">
                <span className="w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center">
                  3
                </span>
                <h5 className="font-bold text-xs text-slate-800 dark:text-slate-200">التثبيت المباشر</h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  ستجد ملف <code>app-debug.apk</code> جاهزًا للتثبيت الفوري على أي هاتف Android.
                </p>
              </div>
            </div>

            {/* Terminal command snippet */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 text-emerald-400 font-mono text-xs dir-ltr">
              <code>./gradlew assembleDebug</code>
              <button
                onClick={copyCommand}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white flex items-center gap-1 text-[11px] font-sans"
              >
                {copiedCmd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCmd ? 'تم النسخ' : 'نسخ الأمر'}</span>
              </button>
            </div>
          </div>

          {/* Code Inspector */}
          <div className="space-y-2">
            <h4 className="font-heading font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <FileCode2 className="w-4 h-4 text-emerald-600" />
              <span>معاينة ملفات كود Android Studio المضمنة:</span>
            </h4>

            {/* File Selector */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
              {files.map(f => (
                <button
                  key={f.path}
                  onClick={() => setSelectedFilePath(f.path)}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap text-xs font-mono transition-all ${
                    selectedFilePath === f.path
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {f.path.split('/').pop()}
                </button>
              ))}
            </div>

            {/* Code view */}
            <div className="relative rounded-2xl bg-slate-950 text-slate-100 p-4 font-mono text-xs overflow-x-auto max-h-64 dir-ltr border border-slate-800">
              <div className="text-slate-500 text-[10px] mb-2 border-b border-slate-800 pb-1 flex justify-between items-center">
                <span>{selectedFile.path}</span>
                <span className="text-emerald-400">Kotlin / Android / Gradle</span>
              </div>
              <pre className="text-[11px] leading-relaxed">
                {selectedFile.content}
              </pre>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white transition-colors"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};

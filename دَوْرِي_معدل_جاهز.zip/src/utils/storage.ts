import { Person, TaskItem, TaskLog, UserSettings } from '../types';

const STORAGE_KEYS = {
  PEOPLE: 'dawri_people_v1',
  TASKS: 'dawri_tasks_v1',
  LOGS: 'dawri_logs_v1',
  SETTINGS: 'dawri_settings_v1'
};

const DEFAULT_PEOPLE: Person[] = [
  { id: 'person_1', name: 'محمد', avatarColor: '#10b981', createdAt: new Date().toISOString() },
  { id: 'person_2', name: 'خالد', avatarColor: '#3b82f6', createdAt: new Date().toISOString() },
  { id: 'person_3', name: 'أحمد', avatarColor: '#8b5cf6', createdAt: new Date().toISOString() },
  { id: 'person_4', name: 'نواف', avatarColor: '#f59e0b', createdAt: new Date().toISOString() }
];

const DEFAULT_SETTINGS: UserSettings = {
  theme: 'system',
  primaryColor: 'emerald',
  soundEnabled: true,
  vibrationEnabled: true,
  notificationsEnabled: true,
  currentUserId: 'person_1' // محمد
};

function getDefaultTasks(people: Person[]): TaskItem[] {
  const pIds = people.map(p => p.id);
  const now = new Date();
  
  // Set start of turn for water task to 35 minutes ago to demo live counter
  const waterStartTime = new Date(now.getTime() - 35 * 60 * 1000).toISOString();

  return [
    {
      id: 'task_water',
      title: 'تعبئة الماء',
      icon: '💧',
      type: 'ON_COMPLETE',
      status: 'ACTIVE',
      personIds: pIds,
      currentPersonIndex: 0, // محمد
      turnStartedAt: waterStartTime,
      completedForCurrentCycle: false,
      notifications: {
        enabled: true,
        startAfterMinutes: 120, // ساعتين
        repeatIntervalMinutes: 30, // 30 دقيقة
        countType: 'UNTIL_COMPLETED',
        maxAlertsCount: 5,
        sound: true,
        vibrate: true,
        vibrationIntensity: 'medium'
      },
      createdAt: now.toISOString()
    },
    {
      id: 'task_cleaning',
      title: 'تنظيف المكان',
      icon: '🧹',
      type: 'DAILY',
      status: 'ACTIVE',
      personIds: pIds,
      currentPersonIndex: 1, // خالد
      turnStartedAt: new Date(now.getTime() - 4 * 3600 * 1000).toISOString(),
      completedForCurrentCycle: false,
      notifications: {
        enabled: true,
        startAfterMinutes: 60,
        repeatIntervalMinutes: 60,
        countType: 'UNTIL_COMPLETED',
        maxAlertsCount: 3,
        sound: true,
        vibrate: true
      },
      createdAt: now.toISOString()
    },
    {
      id: 'task_trash',
      title: 'إخراج القمامة',
      icon: '🗑️',
      type: 'EVERY_X_DAYS',
      intervalDays: 2,
      status: 'ACTIVE',
      personIds: pIds,
      currentPersonIndex: 2, // أحمد
      turnStartedAt: new Date(now.getTime() - 12 * 3600 * 1000).toISOString(),
      completedForCurrentCycle: false,
      notifications: {
        enabled: true,
        startAfterMinutes: 180,
        repeatIntervalMinutes: 60,
        countType: 'UNTIL_COMPLETED',
        maxAlertsCount: 4,
        sound: true,
        vibrate: true
      },
      createdAt: now.toISOString()
    }
  ];
}

const DEFAULT_LOGS: TaskLog[] = [
  {
    id: 'log_seed_1',
    taskId: 'task_water',
    personId: 'person_2',
    personName: 'خالد',
    completedAt: new Date(Date.now() - 26 * 3600 * 1000).toISOString(),
    note: 'تم تعبئة خزان الماء بالكامل'
  },
  {
    id: 'log_seed_2',
    taskId: 'task_water',
    personId: 'person_3',
    personName: 'أحمد',
    completedAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString()
  },
  {
    id: 'log_seed_3',
    taskId: 'task_cleaning',
    personId: 'person_1',
    personName: 'محمد',
    completedAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString()
  }
];

export function loadPeople(): Person[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PEOPLE);
    if (!raw) {
      savePeople(DEFAULT_PEOPLE);
      return DEFAULT_PEOPLE;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_PEOPLE;
  }
}

export function savePeople(people: Person[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PEOPLE, JSON.stringify(people));
  } catch {
    // Local storage full or unavailable
  }
}

export function loadTasks(): TaskItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TASKS);
    if (!raw) {
      const people = loadPeople();
      const defaultTasks = getDefaultTasks(people);
      saveTasks(defaultTasks);
      return defaultTasks;
    }
    return JSON.parse(raw);
  } catch {
    const people = loadPeople();
    return getDefaultTasks(people);
  }
}

export function saveTasks(tasks: TaskItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  } catch {
    // Handle storage error
  }
}

export function loadLogs(): TaskLog[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LOGS);
    if (!raw) {
      saveLogs(DEFAULT_LOGS);
      return DEFAULT_LOGS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_LOGS;
  }
}

export function saveLogs(logs: TaskLog[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  } catch {
    // Handle storage error
  }
}

export function loadSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) {
      saveSettings(DEFAULT_SETTINGS);
      return DEFAULT_SETTINGS;
    }
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch {
    // Handle storage error
  }
}

export function resetAllData(): void {
  localStorage.removeItem(STORAGE_KEYS.PEOPLE);
  localStorage.removeItem(STORAGE_KEYS.TASKS);
  localStorage.removeItem(STORAGE_KEYS.LOGS);
  localStorage.removeItem(STORAGE_KEYS.SETTINGS);
}

// Aliases for convenience
export const getStoredTasks = loadTasks;
export const saveStoredTasks = saveTasks;
export const getStoredPeople = loadPeople;
export const saveStoredPeople = savePeople;
export const getStoredLogs = loadLogs;
export const saveStoredLogs = saveLogs;
export const getStoredSettings = loadSettings;
export const saveStoredSettings = saveSettings;
export const resetToDefaults = resetAllData;

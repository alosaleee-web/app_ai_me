import { TaskItem, TaskLog, Person } from '../types';

export interface NextAlertInfo {
  status: 'WAITING_FIRST' | 'REPEATING' | 'COMPLETED' | 'FINISHED_MAX_ALERTS' | 'DISABLED' | 'PAUSED';
  nextAlertTime?: Date;
  secondsRemaining?: number;
  formattedCountdown?: string;
  alertsFiredCount?: number;
  label: string;
}

/**
 * Formats seconds into HH:MM:SS
 */
export function formatCountdown(totalSeconds: number): string {
  if (totalSeconds <= 0) return '00:00:00';
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);

  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

/**
 * Calculates the next alert time and countdown for a given task
 */
export function calculateNextAlert(task: TaskItem, now: Date = new Date()): NextAlertInfo {
  if (task.status === 'PAUSED') {
    return { status: 'PAUSED', label: 'المهمة متوقفة مؤقتًا' };
  }
  if (task.status === 'ARCHIVED') {
    return { status: 'COMPLETED', label: 'المهمة مؤرشفة' };
  }
  if (!task.notifications.enabled) {
    return { status: 'DISABLED', label: 'التنبيهات معطلة' };
  }
  if (task.completedForCurrentCycle && (task.type === 'DAILY' || task.type === 'EVERY_X_DAYS')) {
    return { status: 'COMPLETED', label: 'أُنجزت للدورة الحالية' };
  }

  const turnStart = new Date(task.turnStartedAt).getTime();
  const nowMs = now.getTime();
  const startAfterMs = task.notifications.startAfterMinutes * 60 * 1000;
  const repeatIntervalMs = Math.max(1, task.notifications.repeatIntervalMinutes) * 60 * 1000;
  
  const firstAlertMs = turnStart + startAfterMs;

  // Case 1: Before first alert
  if (nowMs < firstAlertMs) {
    const diffSec = Math.max(0, Math.floor((firstAlertMs - nowMs) / 1000));
    return {
      status: 'WAITING_FIRST',
      nextAlertTime: new Date(firstAlertMs),
      secondsRemaining: diffSec,
      formattedCountdown: formatCountdown(diffSec),
      alertsFiredCount: 0,
      label: 'أول تذكير بعد'
    };
  }

  // Case 2: After first alert has passed
  const timeSinceFirst = nowMs - firstAlertMs;
  const intervalsPassed = Math.floor(timeSinceFirst / repeatIntervalMs);
  const alertsFiredSoFar = 1 + intervalsPassed;

  if (task.notifications.countType === 'EXACT_COUNT') {
    if (alertsFiredSoFar >= task.notifications.maxAlertsCount) {
      return {
        status: 'FINISHED_MAX_ALERTS',
        alertsFiredCount: task.notifications.maxAlertsCount,
        label: `انتهت التنبيهات المحددة (${task.notifications.maxAlertsCount})`
      };
    }
  }

  // Next repeating alert
  const nextAlertMs = firstAlertMs + (intervalsPassed + 1) * repeatIntervalMs;
  const diffSec = Math.max(0, Math.floor((nextAlertMs - nowMs) / 1000));

  return {
    status: 'REPEATING',
    nextAlertTime: new Date(nextAlertMs),
    secondsRemaining: diffSec,
    formattedCountdown: formatCountdown(diffSec),
    alertsFiredCount: alertsFiredSoFar,
    label: 'التذكير التالي بعد'
  };
}

/**
 * Completes the task, rotates the person according to rules, and creates a log entry
 */
export function completeCurrentTurn(
  task: TaskItem,
  people: Person[],
  note?: string
): { updatedTask: TaskItem; logEntry: TaskLog } {
  const currentPersonId = task.personIds[task.currentPersonIndex] || task.personIds[0];
  const currentPerson = people.find(p => p.id === currentPersonId);
  const now = new Date();
  const nowIso = now.toISOString();

  const logEntry: TaskLog = {
    id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    taskId: task.id,
    personId: currentPersonId,
    personName: currentPerson?.name || 'مستخدم',
    completedAt: nowIso,
    note
  };

  const totalPeople = task.personIds.length;
  if (totalPeople === 0) {
    return {
      updatedTask: {
        ...task,
        lastCompletedAt: nowIso
      },
      logEntry
    };
  }

  let nextIndex = task.currentPersonIndex;
  let turnStartedAt = task.turnStartedAt;
  let completedForCurrentCycle = false;

  if (task.type === 'ON_COMPLETE') {
    // Moves immediately to the next person, turn starts now from scratch
    nextIndex = (task.currentPersonIndex + 1) % totalPeople;
    turnStartedAt = nowIso;
    completedForCurrentCycle = false;
  } else if (task.type === 'DAILY') {
    // For daily, mark completed for today. The turn advances tomorrow!
    completedForCurrentCycle = true;
    // Turn started date will be updated when the next day cycle is triggered or we advance next index for tomorrow
    // Note: User rule: "إذا أنجز الشخص مهمته اليومية، لا ينتقل الدور مباشرة إلى الشخص التالي في نفس اليوم. الدور التالي يبدأ عند بداية الدورة الزمنية التالية."
  } else if (task.type === 'EVERY_X_DAYS') {
    completedForCurrentCycle = true;
  } else if (task.type === 'WEEKLY') {
    completedForCurrentCycle = true;
  } else {
    // CUSTOM
    nextIndex = (task.currentPersonIndex + 1) % totalPeople;
    turnStartedAt = nowIso;
  }

  const updatedTask: TaskItem = {
    ...task,
    currentPersonIndex: nextIndex,
    turnStartedAt,
    completedForCurrentCycle,
    lastCompletedAt: nowIso
  };

  return { updatedTask, logEntry };
}

/**
 * Checks if a daily or interval task should roll over to the next day/cycle
 */
export function checkCycleRollOver(task: TaskItem): TaskItem {
  if (!task.completedForCurrentCycle || !task.lastCompletedAt) {
    return task;
  }

  const lastCompleted = new Date(task.lastCompletedAt);
  const now = new Date();

  if (task.type === 'DAILY') {
    // If today is a calendar day after lastCompleted
    const isNewDay = 
      now.getFullYear() > lastCompleted.getFullYear() ||
      now.getMonth() > lastCompleted.getMonth() ||
      now.getDate() > lastCompleted.getDate();

    if (isNewDay) {
      const nextIndex = (task.currentPersonIndex + 1) % task.personIds.length;
      return {
        ...task,
        currentPersonIndex: nextIndex,
        completedForCurrentCycle: false,
        turnStartedAt: now.toISOString()
      };
    }
  } else if (task.type === 'EVERY_X_DAYS') {
    const days = task.intervalDays || 2;
    const diffDays = Math.floor((now.getTime() - lastCompleted.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays >= days) {
      const nextIndex = (task.currentPersonIndex + 1) % task.personIds.length;
      return {
        ...task,
        currentPersonIndex: nextIndex,
        completedForCurrentCycle: false,
        turnStartedAt: now.toISOString()
      };
    }
  }

  return task;
}

export function checkAndHandleCycleRollOver(tasks: TaskItem[]): TaskItem[] {
  return tasks.map(t => checkCycleRollOver(t));
}

/**
 * Helper to get Arabic task type label
 */
export function getTaskTypeLabel(type: TaskItem['type'], intervalDays?: number): string {
  switch (type) {
    case 'ON_COMPLETE':
      return 'عند الإنجاز';
    case 'DAILY':
      return 'يومي';
    case 'EVERY_X_DAYS':
      return `كل ${intervalDays || 2} أيام`;
    case 'WEEKLY':
      return 'أسبوعي';
    case 'CUSTOM':
      return 'موعد مخصص';
    default:
      return 'متناوب';
  }
}

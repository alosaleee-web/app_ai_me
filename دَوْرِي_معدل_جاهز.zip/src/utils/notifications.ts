import { playNotificationChime, triggerVibration } from './audio';

export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  if (Notification.permission === 'granted') {
    return 'granted';
  }
  try {
    return await Notification.requestPermission();
  } catch {
    return 'denied';
  }
}

export function hasNotificationPermission(): boolean {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  return Notification.permission === 'granted';
}

export function showLocalNotification(options: {
  title: string;
  body: string;
  icon?: string;
  sound?: boolean;
  vibrate?: boolean;
  onClick?: () => void;
}) {
  const { title, body, icon = '💧', sound = true, vibrate = true, onClick } = options;

  if (sound) {
    playNotificationChime();
  }
  if (vibrate) {
    triggerVibration([200, 100, 250]);
  }

  if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      const notif = new Notification(title, {
        body,
        icon: '/favicon.ico',
        tag: 'dawri-task-alert',
        badge: '/favicon.ico',
        lang: 'ar',
        dir: 'rtl'
      });

      if (onClick) {
        notif.onclick = () => {
          window.focus();
          onClick();
          notif.close();
        };
      }
    } catch {
      // Fallback in environments without Notification constructor
    }
  }
}

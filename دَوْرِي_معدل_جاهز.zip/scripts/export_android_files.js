import fs from 'fs';
import path from 'path';
import { getAndroidProjectFiles } from '../src/androidProject/androidCode.ts';

const files = getAndroidProjectFiles();
const outDir = path.resolve(process.cwd(), 'android');

for (const file of files) {
  const filePath = path.join(outDir, file.path);
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(filePath, file.content, 'utf-8');
}

console.log(`Successfully exported ${files.length} Android Native files to ./android/`);

package com.dawri.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TaskType {
    ON_COMPLETE,    // عند إنجاز المهمة
    DAILY,          // يومي
    EVERY_X_DAYS,   // كل X أيام
    WEEKLY,         // أسبوعي
    CUSTOM          // موعد مخصص
}

enum class TaskStatus {
    ACTIVE,
    PAUSED,
    ARCHIVED
}

enum class AlertCountType {
    UNTIL_COMPLETED, // حتى إنجاز المهمة
    EXACT_COUNT      // عدد محدد
}

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey val id: String,
    val title: String,
    val icon: String = "💧",
    val type: TaskType = TaskType.ON_COMPLETE,
    val status: TaskStatus = TaskStatus.ACTIVE,

    // Comma-separated list of person IDs in sequential order
    val personIdsJson: String,
    val currentPersonIndex: Int = 0,

    val intervalDays: Int = 2,
    val weeklyDay: Int = 5, // Friday = 5
    val customStartTime: Long? = null,

    val turnStartedAt: Long = System.currentTimeMillis(),
    val completedForCurrentCycle: Boolean = false,
    val lastCompletedAt: Long? = null,

    // Notification config
    val notificationsEnabled: Boolean = true,
    val startAfterMinutes: Int = 120, // 2 hours
    val repeatIntervalMinutes: Int = 30, // 30 mins
    val alertCountType: AlertCountType = AlertCountType.UNTIL_COMPLETED,
    val maxAlertsCount: Int = 5,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,

    val createdAt: Long = System.currentTimeMillis()
) {
    fun getOrderedPersonIds(): List<String> {
        if (personIdsJson.isBlank()) return emptyList()
        return personIdsJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun getCurrentPersonId(): String? {
        val list = getOrderedPersonIds()
        if (list.isEmpty()) return null
        return list.getOrNull(currentPersonIndex % list.size) ?: list.firstOrNull()
    }
}

package com.dawri.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dawri.app.DawriApplication
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.Task
import com.dawri.app.data.model.TaskType
import com.dawri.app.notification.AlarmScheduler
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateEditTaskScreen(
    taskId: String?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as DawriApplication
    val repository = app.repository
    val scope = rememberCoroutineScope()

    val people by repository.allPersons.collectAsState(initial = emptyList())

    var title by remember { mutableStateOf("") }
    var icon by remember { mutableStateOf("💧") }
    var taskType by remember { mutableStateOf(TaskType.ON_COMPLETE) }
    var startAfterMinutes by remember { mutableStateOf(120) }
    var repeatIntervalMinutes by remember { mutableStateOf(30) }
    var alertCountType by remember { mutableStateOf(AlertCountType.UNTIL_COMPLETED) }
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }

    LaunchedEffect(taskId) {
        if (taskId != null) {
            val existing = repository.getTaskById(taskId)
            if (existing != null) {
                title = existing.title
                icon = existing.icon
                taskType = existing.type
                startAfterMinutes = existing.startAfterMinutes
                repeatIntervalMinutes = existing.repeatIntervalMinutes
                alertCountType = existing.alertCountType
                soundEnabled = existing.soundEnabled
                vibrationEnabled = existing.vibrationEnabled
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (taskId == null) "إضافة مهمة جديدة" else "تعديل المهمة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("اسم المهمة (مثال: تعبئة الماء)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Text("نوع انتقال المهمة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = taskType == TaskType.ON_COMPLETE,
                    onClick = { taskType = TaskType.ON_COMPLETE },
                    label = { Text("عند الإنجاز") }
                )
                FilterChip(
                    selected = taskType == TaskType.DAILY,
                    onClick = { taskType = TaskType.DAILY },
                    label = { Text("يومي") }
                )
                FilterChip(
                    selected = taskType == TaskType.EVERY_X_DAYS,
                    onClick = { taskType = TaskType.EVERY_X_DAYS },
                    label = { Text("كل X أيام") }
                )
            }

            HorizontalDivider()

            Text("إعدادات التنبيه:", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            Text("ابدأ إرسال التذكيرات بعد: ${startAfterMinutes} دقيقة")
            Slider(
                value = startAfterMinutes.toFloat(),
                onValueChange = { startAfterMinutes = it.toInt() },
                valueRange = 5f..240f,
                steps = 15
            )

            Text("كرر التنبيه كل: ${repeatIntervalMinutes} دقيقة")
            Slider(
                value = repeatIntervalMinutes.toFloat(),
                onValueChange = { repeatIntervalMinutes = it.toInt() },
                valueRange = 5f..120f,
                steps = 11
            )

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(checked = soundEnabled, onCheckedChange = { soundEnabled = it })
                Text("صوت التنبيه")
                Spacer(modifier = Modifier.width(16.dp))
                Checkbox(checked = vibrationEnabled, onCheckedChange = { vibrationEnabled = it })
                Text("الاهتزاز")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (title.isBlank()) return@Button
                    scope.launch {
                        val personIdsStr = people.map { it.id }.joinToString(",")
                        val id = taskId ?: "task_${UUID.randomUUID()}"
                        val task = Task(
                            id = id,
                            title = title,
                            icon = icon,
                            type = taskType,
                            personIdsJson = personIdsStr,
                            startAfterMinutes = startAfterMinutes,
                            repeatIntervalMinutes = repeatIntervalMinutes,
                            alertCountType = alertCountType,
                            soundEnabled = soundEnabled,
                            vibrationEnabled = vibrationEnabled
                        )
                        repository.insertTask(task)
                        AlarmScheduler.scheduleNextAlarm(context, task)
                        onBack()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("حفظ المهمة", fontWeight = FontWeight.Bold)
            }
        }
    }
}

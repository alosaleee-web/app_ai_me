package com.dawri.app.notification

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import com.dawri.app.DawriApplication
import com.dawri.app.MainActivity
import com.dawri.app.R
import com.dawri.app.data.local.AppDatabase
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(AlarmScheduler.EXTRA_TASK_ID) ?: return
        val sequence = intent.getIntExtra(AlarmScheduler.EXTRA_ALERT_SEQUENCE, 1)

        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val task = db.taskDao().getTaskById(taskId) ?: return@launch

                if (task.status != TaskStatus.ACTIVE || !task.notificationsEnabled || task.completedForCurrentCycle) {
                    return@launch
                }

                val currentPersonId = task.getCurrentPersonId() ?: ""
                val currentPerson = db.personDao().getPersonById(currentPersonId)
                val personName = currentPerson?.name ?: "صديق"

                val title = "${task.icon} حان دورك: ${task.title}"
                val body = if (sequence == 1) {
                    "يا ${personName}، حان دورك الآن لتنفيذ مهمة ${task.title}"
                } else {
                    "تذكير (${sequence}): مهمة ${task.title} ما زالت عليك يا ${personName}"
                }

                // Intent to open app
                val openIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("OPEN_TASK_ID", task.id)
                }
                val openPendingIntent = PendingIntent.getActivity(
                    context,
                    task.id.hashCode(),
                    openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val notificationBuilder = NotificationCompat.Builder(context, DawriApplication.CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setAutoCancel(true)
                    .setContentIntent(openPendingIntent)

                if (task.soundEnabled) {
                    notificationBuilder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                }
                if (task.vibrationEnabled) {
                    notificationBuilder.setVibrate(longArrayOf(0, 200, 100, 250))
                }

                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.notify(task.id.hashCode(), notificationBuilder.build())

                // Check if we should schedule next repeat
                var shouldScheduleNext = true
                if (task.alertCountType == AlertCountType.EXACT_COUNT && sequence >= task.maxAlertsCount) {
                    shouldScheduleNext = false
                }

                if (shouldScheduleNext) {
                    AlarmScheduler.scheduleNextAlarm(context, task)
                }

            } finally {
                pendingResult.finish()
            }
        }
    }
}

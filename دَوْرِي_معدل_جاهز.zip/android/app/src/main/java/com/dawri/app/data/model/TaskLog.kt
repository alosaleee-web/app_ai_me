package com.dawri.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "task_logs")
data class TaskLog(
    @PrimaryKey val id: String,
    val taskId: String,
    val personId: String,
    val personName: String,
    val completedAt: Long,
    val note: String? = null
)

package com.dawri.app.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.Task
import com.dawri.app.data.model.TaskStatus

object AlarmScheduler {

    const val EXTRA_TASK_ID = "extra_task_id"
    const val EXTRA_ALERT_SEQUENCE = "extra_alert_sequence"

    /**
     * Calculates and schedules the next exact alarm for the given task
     */
    fun scheduleNextAlarm(context: Context, task: Task) {
        // First cancel any existing alarms for this task
        cancelAlarmsForTask(context, task.id)

        if (task.status != TaskStatus.ACTIVE || !task.notificationsEnabled) {
            return
        }
        if (task.completedForCurrentCycle) {
            return
        }

        val now = System.currentTimeMillis()
        val startAfterMs = task.startAfterMinutes * 60 * 1000L
        val repeatIntervalMs = Math.max(1, task.repeatIntervalMinutes) * 60 * 1000L
        val firstAlertTime = task.turnStartedAt + startAfterMs

        var targetTime: Long
        var sequenceNumber: Int

        if (now < firstAlertTime) {
            targetTime = firstAlertTime
            sequenceNumber = 1
        } else {
            val elapsedSinceFirst = now - firstAlertTime
            val intervalsPassed = (elapsedSinceFirst / repeatIntervalMs).toInt()
            sequenceNumber = 1 + intervalsPassed + 1

            if (task.alertCountType == AlertCountType.EXACT_COUNT) {
                if (sequenceNumber > task.maxAlertsCount) {
                    // Reached max scheduled alerts, stop scheduling
                    return
                }
            }
            targetTime = firstAlertTime + (intervalsPassed + 1) * repeatIntervalMs
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.dawri.app.ACTION_TASK_ALERT"
            putExtra(EXTRA_TASK_ID, task.id)
            putExtra(EXTRA_ALERT_SEQUENCE, sequenceNumber)
        }

        val requestCode = task.id.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    targetTime,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    targetTime,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            // In Android 12+ without SCHEDULE_EXACT_ALARM fallback gracefully
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                targetTime,
                pendingIntent
            )
        }
    }

    /**
     * Cancels any scheduled alarm for this task
     */
    fun cancelAlarmsForTask(context: Context, taskId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.dawri.app.ACTION_TASK_ALERT"
        }
        val requestCode = taskId.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}

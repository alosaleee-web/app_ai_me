package com.dawri.app.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.dawri.app.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Reschedules all active alarms after phone reboot or timezone changes
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AppDatabase.getDatabase(context)
                    val tasks = db.taskDao().getAllTasksDirect()
                    for (task in tasks) {
                        AlarmScheduler.scheduleNextAlarm(context, task)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}

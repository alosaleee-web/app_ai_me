package com.dawri.app.data.local

import androidx.room.*
import com.dawri.app.data.model.TaskLog
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskLogDao {
    @Query("SELECT * FROM task_logs WHERE taskId = :taskId ORDER BY completedAt DESC")
    fun getLogsForTask(taskId: String): Flow<List<TaskLog>>

    @Query("SELECT * FROM task_logs ORDER BY completedAt DESC LIMIT 100")
    fun getAllLogs(): Flow<List<TaskLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: TaskLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<TaskLog>)
}

package com.dawri.app.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object TaskDetail : Screen("task_detail/{taskId}") {
        fun createRoute(taskId: String) = "task_detail/$taskId"
    }
    object CreateTask : Screen("create_task")
    object EditTask : Screen("edit_task/{taskId}") {
        fun createRoute(taskId: String) = "edit_task/$taskId"
    }
    object Persons : Screen("persons")
    object Settings : Screen("settings")
}

@Composable
fun DawriNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(
                onTaskClick = { taskId -> navController.navigate(Screen.TaskDetail.createRoute(taskId)) },
                onCreateTaskClick = { navController.navigate(Screen.CreateTask.route) },
                onPersonsClick = { navController.navigate(Screen.Persons.route) },
                onSettingsClick = { navController.navigate(Screen.Settings.route) }
            )
        }
        composable(Screen.TaskDetail.route) { backStackEntry ->
            val taskId = backStackEntry.arguments?.getString("taskId") ?: ""
            TaskDetailScreen(
                taskId = taskId,
                onBack = { navController.popBackStack() },
                onEditTask = { navController.navigate(Screen.EditTask.createRoute(taskId)) }
            )
        }
        composable(Screen.CreateTask.route) {
            CreateEditTaskScreen(
                taskId = null,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.EditTask.route) { backStackEntry ->
            val taskId = backStackEntry.arguments?.getString("taskId")
            CreateEditTaskScreen(
                taskId = taskId,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Persons.route) {
            PersonsScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}

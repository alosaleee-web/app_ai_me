package com.dawri.app.data.repository

import com.dawri.app.data.local.PersonDao
import com.dawri.app.data.local.TaskDao
import com.dawri.app.data.local.TaskLogDao
import com.dawri.app.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.*

class DawriRepository(
    private val taskDao: TaskDao,
    private val personDao: PersonDao,
    private val taskLogDao: TaskLogDao
) {
    val allTasks: Flow<List<Task>> = taskDao.getAllActiveTasks()
    val allPersons: Flow<List<Person>> = personDao.getAllPersons()

    suspend fun getTaskById(id: String): Task? = taskDao.getTaskById(id)

    fun getLogsForTask(taskId: String): Flow<List<TaskLog>> = taskLogDao.getLogsForTask(taskId)

    suspend fun insertTask(task: Task) = taskDao.insertTask(task)

    suspend fun updateTask(task: Task) = taskDao.updateTask(task)

    suspend fun deleteTask(task: Task) = taskDao.deleteTask(task)

    suspend fun insertPerson(person: Person) = personDao.insertPerson(person)

    suspend fun updatePerson(person: Person) = personDao.updatePerson(person)

    suspend fun deletePerson(person: Person) {
        personDao.deletePerson(person)
        // Clean up person references in tasks
        val tasks = taskDao.getAllTasksDirect()
        for (task in tasks) {
            val personIds = task.getOrderedPersonIds().toMutableList()
            if (personIds.contains(person.id)) {
                personIds.remove(person.id)
                val newIndex = if (personIds.isEmpty()) 0 else task.currentPersonIndex % personIds.size
                taskDao.updateTask(
                    task.copy(
                        personIdsJson = personIds.joinToString(","),
                        currentPersonIndex = newIndex
                    )
                )
            }
        }
    }

    /**
     * Executes the task completion and advances the turn
     */
    suspend fun completeTask(task: Task, note: String? = null): Task {
        val now = System.currentTimeMillis()
        val personIds = task.getOrderedPersonIds()
        val currentPersonId = task.getCurrentPersonId() ?: ""
        val currentPerson = personDao.getPersonById(currentPersonId)

        // 1. Record log
        val log = TaskLog(
            id = "log_${UUID.randomUUID()}",
            taskId = task.id,
            personId = currentPersonId,
            personName = currentPerson?.name ?: "مستخدم",
            completedAt = now,
            note = note
        )
        taskLogDao.insertLog(log)

        // 2. Determine next turn
        val total = personIds.size
        var nextIndex = task.currentPersonIndex
        var turnStartedAt = task.turnStartedAt
        var completedForCurrentCycle = false

        when (task.type) {
            TaskType.ON_COMPLETE -> {
                if (total > 0) {
                    nextIndex = (task.currentPersonIndex + 1) % total
                }
                turnStartedAt = now
                completedForCurrentCycle = false
            }
            TaskType.DAILY -> {
                // Today is completed for this person. Next person starts tomorrow.
                completedForCurrentCycle = true
            }
            TaskType.EVERY_X_DAYS -> {
                completedForCurrentCycle = true
            }
            TaskType.WEEKLY -> {
                completedForCurrentCycle = true
            }
            TaskType.CUSTOM -> {
                if (total > 0) {
                    nextIndex = (task.currentPersonIndex + 1) % total
                }
                turnStartedAt = now
            }
        }

        val updated = task.copy(
            currentPersonIndex = nextIndex,
            turnStartedAt = turnStartedAt,
            completedForCurrentCycle = completedForCurrentCycle,
            lastCompletedAt = now
        )
        taskDao.updateTask(updated)
        return updated
    }

    suspend fun populateDefaultDataIfNeeded() {
        val existingPersons = taskDao.getAllTasksDirect()
        if (existingPersons.isNotEmpty()) return

        val p1 = Person("person_1", "محمد", "#10B981")
        val p2 = Person("person_2", "خالد", "#3B82F6")
        val p3 = Person("person_3", "أحمد", "#8B5CF6")
        val p4 = Person("person_4", "نواف", "#F59E0B")

        personDao.insertAll(listOf(p1, p2, p3, p4))

        val now = System.currentTimeMillis()
        val personIdsStr = listOf(p1.id, p2.id, p3.id, p4.id).joinToString(",")

        val waterTask = Task(
            id = "task_water",
            title = "تعبئة الماء",
            icon = "💧",
            type = TaskType.ON_COMPLETE,
            status = TaskStatus.ACTIVE,
            personIdsJson = personIdsStr,
            currentPersonIndex = 0, // محمد
            turnStartedAt = now,
            startAfterMinutes = 120, // 2 hours
            repeatIntervalMinutes = 30, // 30 minutes
            alertCountType = AlertCountType.UNTIL_COMPLETED,
            soundEnabled = true,
            vibrationEnabled = true
        )

        val cleaningTask = Task(
            id = "task_cleaning",
            title = "تنظيف المكان",
            icon = "🧹",
            type = TaskType.DAILY,
            status = TaskStatus.ACTIVE,
            personIdsJson = personIdsStr,
            currentPersonIndex = 1, // خالد
            turnStartedAt = now,
            startAfterMinutes = 60,
            repeatIntervalMinutes = 60
        )

        val trashTask = Task(
            id = "task_trash",
            title = "إخراج القمامة",
            icon = "🗑️",
            type = TaskType.EVERY_X_DAYS,
            intervalDays = 2,
            status = TaskStatus.ACTIVE,
            personIdsJson = personIdsStr,
            currentPersonIndex = 2, // أحمد
            turnStartedAt = now,
            startAfterMinutes = 180,
            repeatIntervalMinutes = 60
        )

        taskDao.insertAll(listOf(waterTask, cleaningTask, trashTask))
    }
}

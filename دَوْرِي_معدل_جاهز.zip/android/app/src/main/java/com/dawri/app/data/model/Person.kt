package com.dawri.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "persons")
data class Person(
    @PrimaryKey val id: String,
    val name: String,
    val avatarColor: String,
    val createdAt: Long = System.currentTimeMillis()
)

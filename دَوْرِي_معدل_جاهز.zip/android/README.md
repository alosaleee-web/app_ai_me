# مشروع تطبيق "دَوْرِي" - Android Native (Kotlin + Jetpack Compose)

تطبيق Android أصلي متكامل لإدارة المهام المتناوبة بين الأشخاص مع نظام إشعارات AlarmManager الدقيق والعمل دون إنترنت.

## مميزات المشروع
- **لغة البرمجة**: Kotlin + Jetpack Compose + Material 3
- **المعمارية**: MVVM مع Room SQLite Database و Coroutines Flow
- **الإشعارات**: Android `AlarmManager.setExactAndAllowWhileIdle`
- **قناة الإشعارات**: `تذكيرات المهام` مع دعم الصوت والاهتزاز
- **إعادة التشغيل**: `BootReceiver` لإعادة جدولة كافة التنبيهات بعد إقلاع الهاتف تلقائيًا
- **تغيير الوقت**: استقبال تغيير المنطقة الزمنية والوقت وإعادة حساب المواعيد دون إرسال تنبيهات متكررة
- **الخصوصية**: محلي بالكامل دون إنترنت ودون Firebase ودون خوادم خارجية

## كيفية فتح وبناء ملف APK في Android Studio

1. فك ضغط ملف المشروع (ZIP).
2. افتح **Android Studio** (نسخة Iguana أو Ladybug أو أحدث).
3. اختر **Open** ثم حدد مجلد المشروع.
4. انتظر حتى ينتهي Android Studio من تحميل وتزامن ملفات Gradle (Sync Project with Gradle Files).
5. لبناء ملف APK Debug قابل للتثبيت على أي هاتف Android:
   - من القائمة العلوية: **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
   - أو عبر سطر الأوامر (Terminal) داخل مجلد المشروع:
     ```bash
     ./gradlew assembleDebug
     ```
6. ستجد ملف الـ APK الناتج جاهزًا للتثبيت مباشرة في المسار:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

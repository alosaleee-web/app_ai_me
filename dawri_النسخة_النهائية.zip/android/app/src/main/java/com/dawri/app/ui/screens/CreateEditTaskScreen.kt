package com.dawri.app.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dawri.app.DawriApplication
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.Task
import com.dawri.app.data.model.TaskType
import com.dawri.app.notification.AlarmScheduler
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun CreateEditTaskScreen(taskId: String?, onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as DawriApplication
    val repository = app.repository
    val scope = rememberCoroutineScope()
    val people by repository.allPersons.collectAsState(initial = emptyList())

    var title by remember { mutableStateOf("") }
    var icon by remember { mutableStateOf("💧") }
    var taskType by remember { mutableStateOf(TaskType.ON_COMPLETE) }
    var intervalDays by remember { mutableStateOf(2) }
    var weeklyDay by remember { mutableStateOf(Calendar.MONDAY) }
    var turnStartedAt by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var startAfterMinutes by remember { mutableStateOf(120) }
    var repeatIntervalMinutes by remember { mutableStateOf(30) }
    var alertCountType by remember { mutableStateOf(AlertCountType.UNTIL_COMPLETED) }
    var maxAlertsCount by remember { mutableStateOf(3) }
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }
    var notificationsEnabled by remember { mutableStateOf(true) }

    var selectedIds by remember { mutableStateOf(listOf<String>()) }
    var currentPersonId by remember { mutableStateOf<String?>(null) }
    var initialized by remember { mutableStateOf(false) }
    var showPeoplePicker by remember { mutableStateOf(false) }
    var showStartPersonPicker by remember { mutableStateOf(false) }

    LaunchedEffect(taskId, people) {
        if (!initialized && people.isNotEmpty()) {
            if (taskId != null) {
                repository.getTaskById(taskId)?.let { existing ->
                    title = existing.title
                    icon = existing.icon
                    taskType = existing.type
                    intervalDays = existing.intervalDays
                    weeklyDay = existing.weeklyDay
                    turnStartedAt = existing.customStartTime ?: existing.turnStartedAt
                    startAfterMinutes = existing.startAfterMinutes
                    repeatIntervalMinutes = existing.repeatIntervalMinutes
                    alertCountType = existing.alertCountType
                    maxAlertsCount = existing.maxAlertsCount
                    soundEnabled = existing.soundEnabled
                    vibrationEnabled = existing.vibrationEnabled
                    notificationsEnabled = existing.notificationsEnabled
                    selectedIds = existing.getOrderedPersonIds().filter { id -> people.any { it.id == id } }
                    currentPersonId = existing.getCurrentPersonId()
                }
            }
            initialized = true
        }
    }

    fun openDateTimePicker() {
        val cal = Calendar.getInstance().apply { timeInMillis = turnStartedAt }
        DatePickerDialog(
            context,
            { _, year, month, day ->
                TimePickerDialog(context, { _, hour, minute ->
                    val chosen = Calendar.getInstance().apply {
                        set(year, month, day, hour, minute, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    turnStartedAt = chosen.timeInMillis
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            },
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (taskId == null) "إضافة مهمة" else "تعديل المهمة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
        ) {
            item {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("اسم المهمة") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
            }
            item {
                OutlinedTextField(
                    value = icon,
                    onValueChange = { icon = it.take(2) },
                    label = { Text("أيقونة المهمة (اختياري)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
            }
            item {
                Text("الأشخاص المشاركون", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = { showPeoplePicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (selectedIds.isEmpty()) "اختر الأشخاص لهذه المهمة" else "تم اختيار ${selectedIds.size} شخص")
                }
                if (selectedIds.isNotEmpty()) {
                    Text(
                        "الترتيب الحالي: " + selectedIds.mapNotNull { id -> people.find { it.id == id }?.name }.joinToString(" → "),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
            item {
                Text("ترتيب الدور", fontWeight = FontWeight.Bold)
                Text("اضغط مطولًا على الاسم ثم حرّكه للأعلى أو الأسفل لتغيير ترتيب الدور.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            itemsIndexed(selectedIds, key = { _, id -> id }) { index, id ->
                val person = people.find { it.id == id }
                if (person != null) {
                    var dragOffset by remember(id) { mutableFloatStateOf(0f) }
                    val isCurrent = currentPersonId == id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .pointerInput(selectedIds) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { dragOffset = 0f },
                                    onDragCancel = { dragOffset = 0f },
                                    onDragEnd = { dragOffset = 0f },
                                    onDrag = { change, amount ->
                                        change.consume()
                                        dragOffset += amount.y
                                        val from = selectedIds.indexOf(id)
                                        if (from >= 0 && dragOffset > 55f && from < selectedIds.lastIndex) {
                                            val list = selectedIds.toMutableList()
                                            val tmp = list[from]; list[from] = list[from + 1]; list[from + 1] = tmp
                                            selectedIds = list
                                            dragOffset = 0f
                                        } else if (from > 0 && dragOffset < -55f) {
                                            val list = selectedIds.toMutableList()
                                            val tmp = list[from]; list[from] = list[from - 1]; list[from - 1] = tmp
                                            selectedIds = list
                                            dragOffset = 0f
                                        }
                                    }
                                )
                            },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCurrent) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)
                        )
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DragHandle, contentDescription = "سحب وإفلات", tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("${index + 1}", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(10.dp))
                            Text(person.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            IconButton(enabled = index > 0, onClick = {
                                val list = selectedIds.toMutableList(); val tmp = list[index]; list[index] = list[index - 1]; list[index - 1] = tmp; selectedIds = list
                            }) { Icon(Icons.Default.KeyboardArrowUp, "أعلى") }
                            IconButton(enabled = index < selectedIds.lastIndex, onClick = {
                                val list = selectedIds.toMutableList(); val tmp = list[index]; list[index] = list[index + 1]; list[index + 1] = tmp; selectedIds = list
                            }) { Icon(Icons.Default.KeyboardArrowDown, "أسفل") }
                        }
                    }
                }
            }
            item {
                OutlinedButton(
                    onClick = { showStartPersonPicker = true },
                    enabled = selectedIds.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("بداية الدور: ${people.find { it.id == (currentPersonId ?: selectedIds.firstOrNull()) }?.name ?: "اختر شخصًا"}")
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.KeyboardArrowDown, null)
                }
            }
            item {
                Text("نوع المهمة", fontWeight = FontWeight.Bold)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        TaskType.ON_COMPLETE to "عند الإنجاز",
                        TaskType.DAILY to "يومي",
                        TaskType.EVERY_X_DAYS to "كل X أيام",
                        TaskType.WEEKLY to "أسبوعي",
                        TaskType.CUSTOM to "موعد مخصص"
                    ).forEach { (type, label) ->
                        FilterChip(selected = taskType == type, onClick = { taskType = type }, label = { Text(label) })
                    }
                }
            }
            if (taskType == TaskType.EVERY_X_DAYS) {
                item {
                    OutlinedTextField(value = intervalDays.toString(), onValueChange = { intervalDays = it.filter(Char::isDigit).toIntOrNull()?.coerceAtLeast(1) ?: 1 }, label = { Text("كل كم يوم؟") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
            }
            if (taskType == TaskType.WEEKLY) {
                item {
                    Text("يوم الأسبوع", fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf(Calendar.SATURDAY to "السبت", Calendar.SUNDAY to "الأحد", Calendar.MONDAY to "الاثنين", Calendar.TUESDAY to "الثلاثاء", Calendar.WEDNESDAY to "الأربعاء", Calendar.THURSDAY to "الخميس", Calendar.FRIDAY to "الجمعة").forEach { (day, label) ->
                            FilterChip(selected = weeklyDay == day, onClick = { weeklyDay = day }, label = { Text(label.take(2)) })
                        }
                    }
                }
            }
            if (taskType != TaskType.ON_COMPLETE) {
                item {
                    Text("بداية الدورة", fontWeight = FontWeight.Medium)
                    OutlinedButton(onClick = ::openDateTimePicker, modifier = Modifier.fillMaxWidth()) {
                        Text(SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()).format(Date(turnStartedAt)))
                    }
                }
            }
            item {
                HorizontalDivider()
                Text("التنبيهات", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = notificationsEnabled, onCheckedChange = { notificationsEnabled = it })
                    Spacer(Modifier.width(8.dp)); Text("تفعيل تنبيهات هذه المهمة")
                }
            }
            if (notificationsEnabled) {
                item {
                    OutlinedTextField(value = startAfterMinutes.toString(), onValueChange = { startAfterMinutes = it.filter(Char::isDigit).toIntOrNull()?.coerceAtLeast(1) ?: 1 }, label = { Text("ابدأ التنبيه بعد (دقائق)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
                item {
                    OutlinedTextField(value = repeatIntervalMinutes.toString(), onValueChange = { repeatIntervalMinutes = it.filter(Char::isDigit).toIntOrNull()?.coerceAtLeast(1) ?: 1 }, label = { Text("كرر التنبيه كل (دقائق)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
                item {
                    Text("عدد التنبيهات", fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = alertCountType == AlertCountType.UNTIL_COMPLETED, onClick = { alertCountType = AlertCountType.UNTIL_COMPLETED }, label = { Text("حتى الإنجاز") })
                        FilterChip(selected = alertCountType == AlertCountType.EXACT_COUNT, onClick = { alertCountType = AlertCountType.EXACT_COUNT }, label = { Text("عدد محدد") })
                    }
                    if (alertCountType == AlertCountType.EXACT_COUNT) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = maxAlertsCount.toString(), onValueChange = { maxAlertsCount = it.filter(Char::isDigit).toIntOrNull()?.coerceAtLeast(1) ?: 1 }, label = { Text("عدد التنبيهات") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = soundEnabled, onCheckedChange = { soundEnabled = it }); Text("الصوت")
                        Spacer(Modifier.width(18.dp)); Checkbox(checked = vibrationEnabled, onCheckedChange = { vibrationEnabled = it }); Text("الاهتزاز")
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        if (title.isBlank() || selectedIds.isEmpty()) return@Button
                        scope.launch {
                            val effectiveCurrent = currentPersonId?.takeIf { selectedIds.contains(it) } ?: selectedIds.first()
                            val currentIndex = selectedIds.indexOf(effectiveCurrent).coerceAtLeast(0)
                            val id = taskId ?: "task_${UUID.randomUUID()}"
                            val existing = taskId?.let { repository.getTaskById(it) }
                            val task = Task(
                                id = id,
                                title = title.trim(),
                                icon = icon.ifBlank { "📌" },
                                type = taskType,
                                status = existing?.status ?: com.dawri.app.data.model.TaskStatus.ACTIVE,
                                personIdsJson = selectedIds.joinToString(","),
                                currentPersonIndex = currentIndex,
                                intervalDays = intervalDays,
                                weeklyDay = weeklyDay,
                                customStartTime = if (taskType == TaskType.CUSTOM) turnStartedAt else null,
                                turnStartedAt = if (existing != null && currentIndex == existing.currentPersonIndex) existing.turnStartedAt else turnStartedAt,
                                completedForCurrentCycle = false,
                                lastCompletedAt = existing?.lastCompletedAt,
                                notificationsEnabled = notificationsEnabled,
                                startAfterMinutes = startAfterMinutes,
                                repeatIntervalMinutes = repeatIntervalMinutes,
                                alertCountType = alertCountType,
                                maxAlertsCount = maxAlertsCount,
                                soundEnabled = soundEnabled,
                                vibrationEnabled = vibrationEnabled,
                                createdAt = existing?.createdAt ?: System.currentTimeMillis()
                            )
                            repository.insertTask(task)
                            AlarmScheduler.scheduleNextAlarm(context, task)
                            onBack()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Icon(Icons.Default.Check, null); Spacer(Modifier.width(8.dp)); Text("حفظ المهمة", fontWeight = FontWeight.Bold) }
            }
        }
    }

    if (showPeoplePicker) {
        AlertDialog(
            onDismissRequest = { showPeoplePicker = false },
            title = { Text("اختر الأشخاص") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (people.isEmpty()) Text("أضف أشخاصًا أولًا من قسم الأشخاص.")
                    people.forEach { person ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Checkbox(checked = selectedIds.contains(person.id), onCheckedChange = { checked ->
                                selectedIds = if (checked) selectedIds + person.id else selectedIds.filterNot { it == person.id }
                                if (!checked && currentPersonId == person.id) currentPersonId = null
                            })
                            Text(person.name)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPeoplePicker = false }) { Text("تم") } }
        )
    }

    if (showStartPersonPicker) {
        AlertDialog(
            onDismissRequest = { showStartPersonPicker = false },
            title = { Text("اختر من يبدأ الدور") },
            text = {
                Column { selectedIds.mapNotNull { id -> people.find { it.id == id } }.forEach { person ->
                    TextButton(onClick = { currentPersonId = person.id; showStartPersonPicker = false }, modifier = Modifier.fillMaxWidth()) { Text(person.name) }
                } }
            },
            confirmButton = { TextButton(onClick = { showStartPersonPicker = false }) { Text("إلغاء") } }
        )
    }
}

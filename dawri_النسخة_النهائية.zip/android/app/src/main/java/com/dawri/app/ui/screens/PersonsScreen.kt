package com.dawri.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dawri.app.DawriApplication
import com.dawri.app.data.model.Person
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as DawriApplication
    val repository = app.repository
    val scope = rememberCoroutineScope()
    val people by repository.allPersons.collectAsState(initial = emptyList())

    var editingPerson by remember { mutableStateOf<Person?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الأشخاص", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } },
                actions = { IconButton(onClick = { name = ""; editingPerson = null; showAdd = true }) { Icon(Icons.Default.Add, "إضافة شخص") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (people.isEmpty()) item { Text("لا يوجد أشخاص بعد. أضف أول شخص من زر +.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(people, key = { it.id }) { person ->
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("👤", fontSize = 22.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(person.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        IconButton(onClick = { name = person.name; editingPerson = person; showAdd = true }) { Icon(Icons.Default.Edit, "تعديل") }
                        IconButton(onClick = { scope.launch { repository.deletePerson(person) } }) { Icon(Icons.Default.Delete, "حذف", tint = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(if (editingPerson == null) "إضافة شخص" else "تعديل الاسم") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الشخص") }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    val clean = name.trim()
                    if (clean.isNotEmpty()) {
                        scope.launch {
                            val current = editingPerson
                            if (current == null) repository.insertPerson(Person("person_${UUID.randomUUID()}", clean, "#1565C0"))
                            else repository.updatePerson(current.copy(name = clean))
                            showAdd = false
                        }
                    }
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
        )
    }
}

package com.dawri.app.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.Task
import com.dawri.app.data.model.TaskStatus
import java.util.Calendar

object AlarmScheduler {
    const val EXTRA_TASK_ID = "extra_task_id"
    const val EXTRA_ALERT_SEQUENCE = "extra_alert_sequence"
    const val ACTION = "com.dawri.app.ACTION_TASK_ALERT"

    fun scheduleNextAlarm(context: Context, task: Task) {
        cancelAlarmsForTask(context, task.id)
        if (task.status != TaskStatus.ACTIVE || !task.notificationsEnabled) return

        // For recurring calendar-based tasks, completion means the current cycle is finished.
        // A sequence 0 alarm opens the next cycle on time; only then are reminders scheduled.
        if (task.completedForCurrentCycle) {
            val nextCycle = nextCycleStart(task) ?: return
            schedule(context, task.id, nextCycle, 0)
            return
        }

        val now = System.currentTimeMillis()
        val firstAlert = task.turnStartedAt + task.startAfterMinutes.coerceAtLeast(1) * 60_000L
        if (task.alertCountType == AlertCountType.EXACT_COUNT && task.maxAlertsCount <= 0) return

        val target: Long
        val sequence: Int
        if (now < firstAlert) {
            target = firstAlert
            sequence = 1
        } else {
            val interval = task.repeatIntervalMinutes.coerceAtLeast(1) * 60_000L
            val elapsed = now - firstAlert
            val intervalsPassed = (elapsed / interval).toInt()
            sequence = intervalsPassed + 2
            if (task.alertCountType == AlertCountType.EXACT_COUNT && sequence > task.maxAlertsCount) return
            target = firstAlert + (intervalsPassed + 1) * interval
        }
        schedule(context, task.id, target, sequence)
    }

    private fun schedule(context: Context, taskId: String, triggerAt: Long, sequence: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION
            putExtra(EXTRA_TASK_ID, taskId)
            putExtra(EXTRA_ALERT_SEQUENCE, sequence)
        }
        val pending = PendingIntent.getBroadcast(
            context, taskId.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pending)
            }
        } catch (_: SecurityException) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pending)
        }
    }

    private fun nextCycleStart(task: Task): Long? {
        val base = Calendar.getInstance().apply { timeInMillis = task.turnStartedAt }
        return when (task.type) {
            com.dawri.app.data.model.TaskType.DAILY -> {
                base.add(Calendar.DAY_OF_YEAR, 1); base.timeInMillis
            }
            com.dawri.app.data.model.TaskType.EVERY_X_DAYS -> {
                base.add(Calendar.DAY_OF_YEAR, task.intervalDays.coerceAtLeast(1)); base.timeInMillis
            }
            com.dawri.app.data.model.TaskType.WEEKLY -> {
                var days = (task.weeklyDay - base.get(Calendar.DAY_OF_WEEK) + 7) % 7
                if (days == 0) days = 7
                base.add(Calendar.DAY_OF_YEAR, days); base.timeInMillis
            }
            else -> null
        }
    }

    fun cancelAlarmsForTask(context: Context, taskId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, AlarmReceiver::class.java).apply { action = ACTION }
        val pending = PendingIntent.getBroadcast(
            context, taskId.hashCode(), intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        pending?.let { alarmManager.cancel(it); it.cancel() }
    }
}

package com.dawri.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dawri.app.DawriApplication
import com.dawri.app.data.model.Task
import com.dawri.app.notification.AlarmScheduler
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailScreen(
    taskId: String,
    onBack: () -> Unit,
    onEditTask: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as DawriApplication
    val repository = app.repository
    val scope = rememberCoroutineScope()
    var showDeleteDialog by remember { mutableStateOf(false) }

    var task by remember { mutableStateOf<Task?>(null) }
    val people by repository.allPersons.collectAsState(initial = emptyList())
    val logs by repository.getLogsForTask(taskId).collectAsState(initial = emptyList())

    LaunchedEffect(taskId) {
        task = repository.getTaskById(taskId)
    }

    val peopleMap = remember(people) { people.associateBy { it.id } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(task?.title ?: "تفاصيل المهمة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = onEditTask) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        val currentTask = task
        if (currentTask == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    // Header card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = currentTask.icon, fontSize = 32.sp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(text = currentTask.title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                    val currentPerson = peopleMap[currentTask.getCurrentPersonId()]
                                    Text(
                                        text = "الشخص الحالي: ${currentPerson?.name ?: "-"}",
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(16.dp))

                            // Sequence of rotation
                            Text(text = "ترتيب الدور:", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                            val orderedNames = currentTask.getOrderedPersonIds().mapNotNull { peopleMap[it]?.name }
                            Text(
                                text = orderedNames.joinToString(" ← "),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Action button
                            Button(
                                onClick = {
                                    scope.launch {
                                        val updated = repository.completeTask(currentTask)
                                        task = updated
                                        AlarmScheduler.scheduleNextAlarm(context, updated)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تم الإنجاز")
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "📜 سجل الإنجازات",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                if (logs.isEmpty()) {
                    item {
                        Text(
                            text = "لا توجد إنجازات مسجلة بعد",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                    items(logs) { log ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = log.personName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = "تم الإنجاز", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                                }
                                Text(text = sdf.format(Date(log.completedAt)), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("حذف المهمة؟") },
            text = { Text("سيتم حذف المهمة وسجلها من الجهاز وإلغاء جميع تنبيهاتها المجدولة.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        task?.let {
                            AlarmScheduler.cancelAlarmsForTask(context, it.id)
                            repository.deleteTask(it)
                        }
                        showDeleteDialog = false
                        onBack()
                    }
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("إلغاء") } }
        )
    }

}

package com.dawri.app.notification

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import com.dawri.app.DawriApplication
import com.dawri.app.MainActivity
import com.dawri.app.data.local.AppDatabase
import com.dawri.app.data.model.AlertCountType
import com.dawri.app.data.model.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(AlarmScheduler.EXTRA_TASK_ID) ?: return
        val sequence = intent.getIntExtra(AlarmScheduler.EXTRA_ALERT_SEQUENCE, 1)
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val task = db.taskDao().getTaskById(taskId) ?: return@launch
                if (task.status != TaskStatus.ACTIVE || !task.notificationsEnabled) return@launch

                // Sequence 0 = start the next daily/every-X-days/weekly cycle.
                if (sequence == 0 && task.completedForCurrentCycle) {
                    val ids = task.getOrderedPersonIds()
                    val nextIndex = if (ids.isEmpty()) 0 else (task.currentPersonIndex + 1) % ids.size
                    val next = task.copy(
                        currentPersonIndex = nextIndex,
                        turnStartedAt = System.currentTimeMillis(),
                        completedForCurrentCycle = false
                    )
                    db.taskDao().updateTask(next)
                    AlarmScheduler.scheduleNextAlarm(context, next)
                    return@launch
                }

                if (task.completedForCurrentCycle) return@launch

                val currentPerson = db.personDao().getPersonById(task.getCurrentPersonId() ?: "")
                val personName = currentPerson?.name ?: "صديق"
                val title = if (sequence == 1) "${task.icon} حان دورك: ${task.title}" else "${task.icon} تذكير: ${task.title}"
                val body = if (sequence == 1) "يا $personName، حان دورك الآن لتنفيذ المهمة" else "المهمة ما زالت عليك يا $personName"

                val openIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("OPEN_TASK_ID", task.id)
                }
                val openPending = PendingIntent.getActivity(context, task.id.hashCode(), openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

                val builder = NotificationCompat.Builder(context, DawriApplication.CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setAutoCancel(true)
                    .setContentIntent(openPending)
                if (!task.soundEnabled) builder.setSilent(true)
                if (task.vibrationEnabled) builder.setVibrate(longArrayOf(0, 200, 100, 250))

                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(task.id.hashCode(), builder.build())

                if (task.alertCountType != AlertCountType.EXACT_COUNT || sequence < task.maxAlertsCount) {
                    AlarmScheduler.scheduleNextAlarm(context, task)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
